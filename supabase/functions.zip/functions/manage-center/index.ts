// supabase/functions/manage-center/index.ts
// ✅ إدارة السنترات (جانب الأدمن الرئيسي + صاحب السنتر) — action: create | assignTeacher | removeTeacher | listTeachers
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
};

interface TokenPayload { sub: string; clientId?: string; role: string; name: string; }

async function verifyToken(req: Request): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw new Error("⚠️ التوكن مطلوب");
  const token = authHeader.substring(7);
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) throw new Error("⚠️ JWT_SECRET غير مضبوط");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(JWT_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  return (await verify(token, key, "HS256")) as unknown as TokenPayload;
}

const ITERATIONS = 100_000;
function toHex(bytes: Uint8Array): string { return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join(""); }
async function pbkdf2(password: string, salt: Uint8Array, iterations: number): Promise<Uint8Array> {
  const keyMaterial = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, keyMaterial, 256);
  return new Uint8Array(bits);
}
async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hashBytes = await pbkdf2(password, salt, ITERATIONS);
  return `pbkdf2$${ITERATIONS}$${toHex(salt)}$${toHex(hashBytes)}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const payload = await verifyToken(req);
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");

    const body = await req.json();
    const action = body.action;

    // ✅ الأدمن يشوف كل السنترات الموجودة، عشان يقدر يضم مدرس لأي واحد فيهم
    if (action === "listCenters") {
      if (payload.role !== "teacher" || payload.clientId !== "master_admin") {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح بهذه العملية" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { data: centersList } = await supabase.from("centers").select("id, client_id, name").order("name");
      return new Response(JSON.stringify({ success: true, data: centersList || [] }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // ✅ إنشاء سنتر جديد — بس المشرف الرئيسي (master_admin) يقدر يعمل ده، زي إضافة مدرس بالظبط
    if (action === "create") {
      if (payload.role !== "teacher" || payload.clientId !== "master_admin") {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح بهذه العملية" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { clientId, name, ownerName } = body;
      if (!clientId || !name || !ownerName) {
        return new Response(JSON.stringify({ success: false, message: "⚠️ جميع الحقول مطلوبة" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { data: existing } = await supabase.from("centers").select("id").eq("client_id", clientId).maybeSingle();
      if (existing) {
        return new Response(JSON.stringify({ success: false, message: "⚠️ الكود ده مستخدم بالفعل" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const defaultHash = await hashPassword(clientId);
      const { data, error } = await supabase.from("centers").insert({
        client_id: clientId, name, owner_name: ownerName, password_hash: defaultHash, must_change_password: true,
      }).select().single();
      if (error) throw new Error(error.message);
      return new Response(JSON.stringify({ success: true, message: "✅ تم إنشاء السنتر بنجاح", data }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // ✅ ضم مدرس لسنتر — بس الأدمن الرئيسي يقدر يعمل الربط ده حالياً (حماية من ضم نفسك لسنتر غلط)
    // ✅ صاحب السنتر بنفسه ينشئ مدرس جديد تحت سنتره — بدون الحاجة للماستر أدمن خالص
    if (action === "createTeacher") {
      if (payload.role !== "center_owner") {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح بهذه العملية" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { clientId, name } = body;
      if (!clientId || !name) {
        return new Response(JSON.stringify({ success: false, message: "⚠️ جميع الحقول مطلوبة" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      if (clientId === "master_admin") {
        return new Response(JSON.stringify({ success: false, message: "⛔ الكود ده محجوز" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const { data: center } = await supabase.from("centers").select("id").eq("client_id", payload.clientId).maybeSingle();
      if (!center) {
        return new Response(JSON.stringify({ success: false, message: "السنتر غير موجود" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const { data: existing } = await supabase.from("teachers").select("client_id").eq("client_id", clientId).maybeSingle();
      if (existing) {
        return new Response(JSON.stringify({ success: false, message: "⚠️ الكود ده مستخدم بالفعل" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const defaultHash = await hashPassword(clientId);
      const deviceSecretBytes = crypto.getRandomValues(new Uint8Array(16));
      const deviceSecret = Array.from(deviceSecretBytes).map((b) => b.toString(16).padStart(2, "0")).join("");

      // ✅ المدرس ده بيتربط بالسنتر مباشرة من لحظة إنشائه (مش محتاج خطوة ضم منفصلة زي الأدمن)
      const { data: teacher, error } = await supabase.from("teachers").insert({
        client_id: clientId, name, password_hash: defaultHash, must_change_password: true, is_active: true,
        max_students: 0, max_assistants: 3, student_count: 0, device_secret: deviceSecret, center_id: center.id,
        permissions: {
          can_manage_students: true, can_manage_groups: true, can_manage_grades: true, can_manage_payments: true,
          can_manage_books: true, can_send_messages: true, can_view_reports: true, can_view_financial: true,
          can_use_backup: true, can_manage_assistants: true, can_use_rfid: true,
        },
      }).select().single();

      if (error) {
        return new Response(JSON.stringify({ success: false, message: error.message }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      return new Response(JSON.stringify({ success: true, message: `✅ تم إضافة المدرس ${name} للسنتر بنجاح`, data: teacher }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // ✅ صاحب السنتر يقدر يشوف/يعطّل مدرسيه (بدون تعديل صلاحيات الباقة، ده حق الماستر أدمن بس)
    if (action === "toggleTeacherActive") {
      if (payload.role !== "center_owner") {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح بهذه العملية" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { teacherClientId, isActive } = body;
      const { data: center } = await supabase.from("centers").select("id").eq("client_id", payload.clientId).maybeSingle();
      const { data: teacher } = await supabase.from("teachers").select("center_id").eq("client_id", teacherClientId).maybeSingle();
      if (!center || !teacher || teacher.center_id !== center.id) {
        return new Response(JSON.stringify({ success: false, message: "⛔ هذا المدرس ليس تابعاً لسنترك" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      await supabase.from("teachers").update({ is_active: isActive === true }).eq("client_id", teacherClientId);
      return new Response(JSON.stringify({ success: true, message: isActive ? "✅ تم تفعيل المدرس" : "✅ تم تعطيل المدرس" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "assignTeacher") {
      if (payload.role !== "teacher" || payload.clientId !== "master_admin") {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح بهذه العملية" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { teacherClientId, centerId } = body;
      const { error } = await supabase.from("teachers").update({ center_id: centerId || null }).eq("client_id", teacherClientId);
      if (error) throw new Error(error.message);
      return new Response(JSON.stringify({ success: true, message: centerId ? "✅ تم ضم المدرس للسنتر" : "✅ تم فصل المدرس عن السنتر" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // ✅ المدرس نفسه يقدر يتحكم في إيه اللي صاحب السنتر يشوفه بالتفصيل
    // ✅ المدرس يسأل عن حالته: هل هو تابع لسنتر أصلاً، وإيه إعدادات المشاركة الحالية بتاعته
    if (action === "getMySharingStatus") {
      if (payload.role !== "teacher") {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { data: teacher } = await supabase
        .from("teachers").select("center_id, center_sharing_permissions, centers(name)").eq("client_id", payload.clientId).maybeSingle();
      return new Response(JSON.stringify({
        success: true,
        belongsToCenter: !!teacher?.center_id,
        centerName: (teacher as any)?.centers?.name || null,
        permissions: teacher?.center_sharing_permissions || {},
      }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "updateSharingPermissions") {
      if (payload.role !== "teacher") {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { permissions } = body;
      const { error } = await supabase.from("teachers").update({ center_sharing_permissions: permissions }).eq("client_id", payload.clientId);
      if (error) throw new Error(error.message);
      return new Response(JSON.stringify({ success: true, message: "✅ تم تحديث إعدادات المشاركة" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // ✅ صاحب السنتر يشوف كل المدرسين التابعين له
    if (action === "listTeachers") {
      if (payload.role !== "center_owner") {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { data: center } = await supabase.from("centers").select("id").eq("client_id", payload.clientId).maybeSingle();
      if (!center) {
        return new Response(JSON.stringify({ success: false, message: "السنتر غير موجود" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { data: teachers } = await supabase
        .from("teachers").select("client_id, name, student_count, is_active, center_sharing_permissions").eq("center_id", center.id);
      return new Response(JSON.stringify({ success: true, data: teachers || [] }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "setBranding") {
      if (payload.role !== "center_owner") {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { brandLogoUrl, brandColor } = body;
      const updates: any = {};
      if (brandLogoUrl !== undefined) updates.brand_logo_url = brandLogoUrl || null;
      if (brandColor !== undefined) updates.brand_color = brandColor || null;
      const { error } = await supabase.from("centers").update(updates).eq("client_id", payload.clientId);
      if (error) throw new Error(error.message);
      return new Response(JSON.stringify({ success: true, message: "✅ تم حفظ الشعار/اللون بنجاح" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ success: false, message: "⚠️ action غير معروفة" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "حدث خطأ داخلي";
    return new Response(JSON.stringify({ success: false, message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

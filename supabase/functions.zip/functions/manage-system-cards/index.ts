// supabase/functions/manage-system-cards/index.ts
// ✅ دالة موحّدة تجمع revoke-system-card + toggle-card-active + return-card-to-stock + assign-cards-to-teacher
// action: revoke | toggleActive | returnToStock | assign
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
};

interface TokenPayload { sub: string; clientId?: string; role: string; name: string; }

class AuthError extends Error {
  status: number; code?: string;
  constructor(message: string, status = 401, code?: string) { super(message); this.status = status; this.code = code; }
}

async function verifyToken(req: Request): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw new AuthError("⚠️ التوكن مطلوب", 401);
  const token = authHeader.substring(7);
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) throw new Error("⚠️ JWT_SECRET غير مضبوط");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(JWT_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  try { return (await verify(token, key, "HS256")) as unknown as TokenPayload; }
  catch (_e) { throw new AuthError("⚠️ التوكن غير صالح أو منتهي الصلاحية", 401); }
}

function requireAdmin(payload: TokenPayload) {
  if (payload.role !== "teacher" || payload.clientId !== "master_admin") {
    throw new AuthError("⛔ غير مصرح بهذه العملية", 403);
  }
}

function authErrorResponse(error: unknown) {
  const status = error instanceof AuthError ? error.status : 500;
  const code = error instanceof AuthError ? error.code : undefined;
  const message = error instanceof Error ? error.message : "⚠️ خطأ غير معروف";
  return new Response(JSON.stringify({ success: false, message, ...(code ? { code } : {}) }),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

function extractCardIds(body: any): number[] {
  return Array.isArray(body.cardIds) ? body.cardIds : (body.cardId ? [body.cardId] : []);
}

async function handleRevoke(supabase: any, body: any) {
  const cardIds = extractCardIds(body);
  if (cardIds.length === 0) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ لازم تحدد كارت واحد على الأقل" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  const { error, count } = await supabase.from("system_cards").delete({ count: "exact" }).in("id", cardIds);
  if (error) {
    console.error("❌ فشل إلغاء الكروت:", error);
    return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  return new Response(JSON.stringify({ success: true, message: `✅ تم إلغاء ${count} كارت بنجاح` }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

async function handleToggleActive(supabase: any, body: any) {
  const { isActive } = body;
  const cardIds = extractCardIds(body);
  if (cardIds.length === 0 || typeof isActive !== "boolean") {
    return new Response(JSON.stringify({ success: false, message: "⚠️ cardId/cardIds و isActive مطلوبين" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  const { error, count } = await supabase.from("system_cards").update({ is_active: isActive }, { count: "exact" }).in("id", cardIds);
  if (error) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  return new Response(JSON.stringify({ success: true, message: isActive ? `✅ تم تفعيل ${count} كارت` : `✅ تم تعطيل ${count} كارت` }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

async function handleReturnToStock(supabase: any, body: any) {
  const cardIds = extractCardIds(body);
  if (cardIds.length === 0) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ لازم تحدد كارت واحد على الأقل" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  const { error, count } = await supabase.from("system_cards")
    .update({ status: "in_stock", teacher_id: null, student_uid: null, is_active: false, assigned_at: null, linked_at: null }, { count: "exact" })
    .in("id", cardIds);
  if (error) {
    console.error("❌ فشل إرجاع الكروت للمخزون:", error);
    return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  return new Response(JSON.stringify({ success: true, message: `✅ تم إرجاع ${count} كارت للمخزون` }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

async function handleAssign(supabase: any, body: any) {
  const { cardIds, teacherId, centerId } = body;
  if ((!teacherId && !centerId) || !Array.isArray(cardIds) || cardIds.length === 0) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ لازم تحدد مدرس أو سنتر، وقائمة cardIds" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  // ✅ التخصيص لسنتر كامل — الكارت بيبقى متاح لكل المدرسين التابعين للسنتر ده، مش مدرس واحد بس
  if (centerId) {
    const { data: center } = await supabase.from("centers").select("id").eq("id", centerId).maybeSingle();
    if (!center) {
      return new Response(JSON.stringify({ success: false, message: "⚠️ السنتر غير موجود" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const { error, count } = await supabase.from("system_cards")
      .update({ center_id: centerId, teacher_id: null, status: "assigned", assigned_at: new Date().toISOString() }, { count: "exact" })
      .in("id", cardIds).eq("status", "in_stock");
    if (error) {
      console.error("❌ فشل تخصيص الكروت للسنتر:", error);
      return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    return new Response(JSON.stringify({ success: true, message: `✅ تم تخصيص ${count} كارت للسنتر (متاح لكل مدرسيه)` }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const { data: teacher } = await supabase.from("teachers").select("client_id").eq("client_id", teacherId).maybeSingle();
  if (!teacher) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ المدرس غير موجود" }),
      { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  const { error, count } = await supabase.from("system_cards")
    .update({ teacher_id: teacherId, status: "assigned", assigned_at: new Date().toISOString() }, { count: "exact" })
    .in("id", cardIds).eq("status", "in_stock");
  if (error) {
    console.error("❌ فشل تخصيص الكروت:", error);
    return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  return new Response(JSON.stringify({ success: true, message: `✅ تم تخصيص ${count} كارت للمدرس` }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });
  try {
    const payload = await verifyToken(req);
    requireAdmin(payload);
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } });

    const body = await req.json();
    const action = body.action;

    if (action === "revoke") return await handleRevoke(supabase, body);
    if (action === "toggleActive") return await handleToggleActive(supabase, body);
    if (action === "returnToStock") return await handleReturnToStock(supabase, body);
    if (action === "assign") return await handleAssign(supabase, body);

    return new Response(JSON.stringify({ success: false, message: "⚠️ action غير معروفة" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    if (error instanceof AuthError) return authErrorResponse(error);
    console.error("❌ خطأ غير متوقع:", error);
    return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

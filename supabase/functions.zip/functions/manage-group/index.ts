// supabase/functions/manage-group/index.ts
// ✅ دالة موحّدة تجمع create-group + rename-group + delete-group بـ "action" parameter
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
  "Access-Control-Max-Age": "86400",
};

export interface TokenPayload {
  sub: string; clientId?: string; teacherId?: string; role: "teacher" | "assistant" | "parent"; name: string; exp: number;
}

export class AuthError extends Error {
  status: number; code?: string;
  constructor(message: string, status = 401, code?: string) { super(message); this.status = status; this.code = code; }
}

async function getKey() {
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) throw new Error("⚠️ JWT_SECRET غير مضبوط في متغيرات البيئة");
  return await crypto.subtle.importKey("raw", new TextEncoder().encode(JWT_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
}

async function licenseCheckClient() {
  const { createClient } = await import("https://esm.sh/@supabase/supabase-js@2.38.4");
  const url = Deno.env.get("SUPABASE_URL") || Deno.env.get("DATABASE_URL") || "";
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SERVICE_ROLE") || "";
  return createClient(url, key, { auth: { autoRefreshToken: false, persistSession: false } });
}

async function checkLicenseActive(teacherClientId: string): Promise<{ active: boolean; reason?: string }> {
  if (teacherClientId === "master_admin") return { active: true };
  const supabase = await licenseCheckClient();
  const { data: teacher, error } = await supabase.from("teachers").select("is_active, expiry_date").eq("client_id", teacherClientId).maybeSingle();
  if (error || !teacher) return { active: false, reason: "الحساب غير موجود" };
  if (teacher.is_active === false) return { active: false, reason: "الحساب معطّل" };
  if (teacher.expiry_date) {
    const todayCLA = new Date().toISOString().split("T")[0];
    if (teacher.expiry_date < todayCLA) return { active: false, reason: "انتهت صلاحية الترخيص" };
  }
  return { active: true };
}

export async function verifyToken(req: Request): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) throw new AuthError("⚠️ التوكن مطلوب", 401);
  const token = authHeader.substring(7);
  const key = await getKey();
  let payload: TokenPayload;
  try { payload = (await verify(token, key, "HS256")) as unknown as TokenPayload; }
  catch (_e) { throw new AuthError("⚠️ التوكن غير صالح أو منتهي الصلاحية", 401); }
  if (payload.role === "teacher" || payload.role === "assistant") {
    const ownerId = payload.clientId || payload.teacherId;
    if (ownerId) {
      const license = await checkLicenseActive(ownerId);
      if (!license.active) throw new AuthError(`⛔ ${license.reason || "انتهت صلاحية الترخيص"} — يرجى التواصل مع الإدارة`, 402, "LICENSE_EXPIRED");
    }
  }
  return payload;
}

export function authErrorResponse(error: unknown) {
  const status = error instanceof AuthError ? error.status : 500;
  const code = error instanceof AuthError ? error.code : undefined;
  const message = error instanceof Error ? error.message : "⚠️ خطأ غير معروف";
  return new Response(JSON.stringify({ success: false, message, ...(code ? { code } : {}) }),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

export async function requireTeacherPlanPermission(clientId: string, permKey: string): Promise<void> {
  if (clientId === "master_admin") return;
  const supabase = await licenseCheckClient();
  const { data: teacher } = await supabase.from("teachers").select("permissions").eq("client_id", clientId).maybeSingle();
  const perms = teacher?.permissions || {};
  if (perms[permKey] === false) throw new AuthError("⛔ هذه الميزة غير متاحة في باقتك الحالية، تواصل مع الإدارة لتفعيلها", 403, "PLAN_RESTRICTED");
}

export async function requireAssistantPermission(payload: TokenPayload, permKey: string): Promise<void> {
  if (payload.role !== "assistant") return;
  const supabase = await licenseCheckClient();
  const { data: assistant } = await supabase.from("assistants").select("permissions").eq("id", payload.sub).maybeSingle();
  const perms = assistant?.permissions || {};
  if (perms[permKey] !== true) throw new AuthError("⛔ ليس لديك صلاحية لهذا الإجراء، تواصل مع المدرس", 403);
}

async function handleCreate(supabase: any, payload: TokenPayload, body: any) {
  const tokenClientId = payload.clientId || payload.teacherId;
  await requireTeacherPlanPermission(tokenClientId, "can_manage_groups");
  await requireAssistantPermission(payload, "manage_groups");

  const { clientId, groupName, maxStudents } = body;
  if (!clientId || !groupName) {
    return new Response(JSON.stringify({ success: false, message: "جميع الحقول مطلوبة: clientId, groupName" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  if (tokenClientId !== clientId) {
    return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك بهذه العملية" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const { data: existingGroup, error: checkError } = await supabase.from("groups").select("id").eq("teacher_id", clientId).eq("name", groupName).maybeSingle();
  if (checkError) {
    return new Response(JSON.stringify({ success: false, message: `فشل التحقق من المجموعة: ${checkError.message}` }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  if (existingGroup) {
    return new Response(JSON.stringify({ success: false, message: `المجموعة "${groupName}" موجودة مسبقاً` }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const normalizedMax = (maxStudents === "" || maxStudents === null || maxStudents === undefined) ? null : Number(maxStudents);
  const { data: newGroup, error: insertError } = await supabase.from("groups").insert({ teacher_id: clientId, name: groupName, max_students: normalizedMax }).select().single();
  if (insertError) {
    return new Response(JSON.stringify({ success: false, message: `فشل إنشاء المجموعة: ${insertError.message}` }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  await supabase.from("activity_logs").insert({
    client_id: clientId, teacher_id: clientId, action_type: "create_group", entity_type: "group", entity_id: String(newGroup.id),
    details: { group_name: groupName }, performer_id: payload.sub, performer_role: payload.role, performer_name: payload.name,
  });

  return new Response(JSON.stringify({ success: true, message: `تم إنشاء المجموعة "${groupName}" بنجاح`, data: newGroup }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

async function handleRename(supabase: any, payload: TokenPayload, body: any) {
  const tokenClientId = payload.clientId || payload.teacherId;
  await requireTeacherPlanPermission(tokenClientId, "can_manage_groups");
  await requireAssistantPermission(payload, "manage_groups");

  const { clientId, oldName, newName } = body;
  if (!clientId || !oldName || !newName) {
    return new Response(JSON.stringify({ success: false, message: "جميع الحقول مطلوبة: clientId, oldName, newName" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  if (tokenClientId !== clientId) {
    return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك بهذه العملية" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  if (oldName === newName) {
    return new Response(JSON.stringify({ success: true, message: "لا توجد تغييرات في اسم المجموعة" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const { data: group, error: groupError } = await supabase.from("groups").select("id").eq("teacher_id", clientId).eq("name", oldName).maybeSingle();
  if (groupError) console.error("❌ خطأ في البحث عن المجموعة في groups:", groupError);

  const { data: students, error: studentsError } = await supabase.from("students").select("id").eq("teacher_id", clientId).eq("group_name", oldName);
  if (studentsError) console.error("❌ خطأ في جلب الطلاب:", studentsError);

  if (!group && (!students || students.length === 0)) {
    return new Response(JSON.stringify({ success: false, message: `المجموعة "${oldName}" غير موجودة` }),
      { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  let groupUpdated = false;
  let studentsAffected = 0;

  if (group) {
    const { error: updateGroupError } = await supabase.from("groups").update({ name: newName }).eq("id", group.id);
    if (updateGroupError) console.error("❌ فشل تحديث groups:", updateGroupError);
    else groupUpdated = true;
  }

  if (students && students.length > 0) {
    const { error: updateStudentsError } = await supabase.from("students").update({ group_name: newName }).eq("teacher_id", clientId).eq("group_name", oldName);
    if (updateStudentsError) console.error("❌ فشل تحديث students:", updateStudentsError);
    else studentsAffected = students.length;
  }

  await supabase.from("activity_logs").insert({
    client_id: tokenClientId, teacher_id: tokenClientId, action_type: "rename_group", entity_type: "group",
    details: { old_name: oldName, new_name: newName }, performer_id: payload.sub, performer_role: payload.role, performer_name: payload.name,
  });

  return new Response(JSON.stringify({ success: true, message: `تم تغيير اسم المجموعة من "${oldName}" إلى "${newName}"`, data: { oldName, newName, studentsAffected, groupUpdated } }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

async function handleDelete(supabase: any, payload: TokenPayload, body: any) {
  const tokenClientId = payload.clientId || payload.teacherId;
  await requireTeacherPlanPermission(tokenClientId, "can_manage_groups");
  await requireAssistantPermission(payload, "manage_groups");

  const { clientId, groupName } = body;
  if (!clientId || !groupName) {
    return new Response(JSON.stringify({ success: false, message: "جميع الحقول مطلوبة: clientId, groupName" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  if (tokenClientId !== clientId) {
    return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك بهذه العملية" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const { data: students, error: fetchStudentsError } = await supabase.from("students").select("name, uid, parent_phone").eq("teacher_id", clientId).eq("group_name", groupName);
  if (fetchStudentsError) {
    return new Response(JSON.stringify({ success: false, message: `فشل جلب الطلاب: ${fetchStudentsError.message}` }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  if (students && students.length > 0) {
    const { error: deleteStudentsError } = await supabase.from("students").delete().eq("teacher_id", clientId).eq("group_name", groupName);
    if (deleteStudentsError) {
      return new Response(JSON.stringify({ success: false, message: `فشل حذف الطلاب: ${deleteStudentsError.message}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const studentUids = students.map((s: any) => s.uid);
    if (studentUids.length > 0) {
      await supabase.from("system_cards").update({ student_uid: null, linked_at: null }).in("student_uid", studentUids);
    }

    const parentPhones = [...new Set(students.map((s: any) => s.parent_phone).filter(Boolean))];
    for (const phone of parentPhones) {
      const { count: remainingCount } = await supabase.from("students").select("id", { count: "exact", head: true }).eq("parent_phone", phone);
      if (!remainingCount || remainingCount === 0) await supabase.from("parents").delete().eq("phone", phone);
    }
  }

  const { error: deleteGroupError } = await supabase.from("groups").delete().eq("teacher_id", clientId).eq("name", groupName);
  if (deleteGroupError) console.error("❌ فشل حذف المجموعة من groups:", deleteGroupError);

  const { count } = await supabase.from("students").select("id", { count: "exact", head: true }).eq("teacher_id", clientId);
  await supabase.from("teachers").update({ student_count: count }).eq("client_id", clientId);

  await supabase.from("activity_logs").insert({
    client_id: clientId, teacher_id: clientId, action_type: "delete_group", entity_type: "group",
    details: { group_name: groupName, students_deleted: students?.length || 0 },
    performer_id: payload.sub, performer_role: payload.role, performer_name: payload.name,
  });

  return new Response(JSON.stringify({ success: true, message: `تم حذف المجموعة "${groupName}" و ${students?.length || 0} طالب`, data: { groupName, studentsDeleted: students?.length || 0 } }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

async function handleSetCapacity(supabase: any, payload: TokenPayload, body: any) {
  const tokenClientId = payload.clientId || payload.teacherId;
  await requireTeacherPlanPermission(tokenClientId, "can_manage_groups");
  await requireAssistantPermission(payload, "manage_groups");

  const { clientId, groupName, maxStudents } = body;
  if (!clientId || !groupName) {
    return new Response(JSON.stringify({ success: false, message: "جميع الحقول مطلوبة: clientId, groupName" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  if (tokenClientId !== clientId) {
    return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك بهذه العملية" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const normalizedMax = (maxStudents === "" || maxStudents === null || maxStudents === undefined) ? null : Number(maxStudents);

  // ✅ بعض المجموعات القديمة اتعملت بس من خلال group_name على الطلاب، من غير صف في جدول groups —
  // لو مفيش صف، بننشئه دلوقتي عشان نقدر نحفظ الحد الأقصى
  const { data: existingGroup } = await supabase.from("groups").select("id").eq("teacher_id", clientId).eq("name", groupName).maybeSingle();

  if (existingGroup) {
    const { error: updateError } = await supabase.from("groups").update({ max_students: normalizedMax }).eq("id", existingGroup.id);
    if (updateError) {
      return new Response(JSON.stringify({ success: false, message: `فشل تحديث الحد الأقصى: ${updateError.message}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
  } else {
    const { error: insertError } = await supabase.from("groups").insert({ teacher_id: clientId, name: groupName, max_students: normalizedMax });
    if (insertError) {
      return new Response(JSON.stringify({ success: false, message: `فشل حفظ الحد الأقصى: ${insertError.message}` }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
  }

  return new Response(JSON.stringify({ success: true, message: normalizedMax ? `تم تحديد الحد الأقصى بـ ${normalizedMax} طالب` : "تم إلغاء الحد الأقصى" }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

async function handleListDetailed(supabase: any, payload: TokenPayload, body: any) {
  const tokenClientId = payload.clientId || payload.teacherId;
  const { clientId } = body;
  if (clientId && clientId !== tokenClientId) {
    return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك بهذه العملية" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const { data: groupRows, error: groupsError } = await supabase.from("groups").select("name, max_students").eq("teacher_id", tokenClientId);
  if (groupsError) {
    return new Response(JSON.stringify({ success: false, message: `فشل جلب المجموعات: ${groupsError.message}` }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const { data: students, error: studentsError } = await supabase.from("students").select("group_name").eq("teacher_id", tokenClientId).not("group_name", "is", null);
  if (studentsError) {
    return new Response(JSON.stringify({ success: false, message: `فشل جلب الطلاب: ${studentsError.message}` }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const countByGroup: Record<string, number> = {};
  (students || []).forEach((s: any) => { countByGroup[s.group_name] = (countByGroup[s.group_name] || 0) + 1; });

  const maxByGroup: Record<string, number | null> = {};
  (groupRows || []).forEach((g: any) => { maxByGroup[g.name] = g.max_students ?? null; });

  const allNames = [...new Set([...Object.keys(countByGroup), ...Object.keys(maxByGroup)])].sort();
  const data = allNames.map((name) => ({
    name,
    studentCount: countByGroup[name] || 0,
    maxStudents: maxByGroup[name] ?? null,
  }));

  return new Response(JSON.stringify({ success: true, data }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const payload = await verifyToken(req);
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } });

    let body: any;
    try { body = await req.json(); }
    catch (_e) {
      return new Response(JSON.stringify({ success: false, message: "الطلب يجب أن يحتوي على JSON صالح" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const action = body.action;
    if (action === "create") return await handleCreate(supabase, payload, body);
    if (action === "rename") return await handleRename(supabase, payload, body);
    if (action === "delete") return await handleDelete(supabase, payload, body);
    if (action === "setCapacity") return await handleSetCapacity(supabase, payload, body);
    if (action === "listDetailed") return await handleListDetailed(supabase, payload, body);

    return new Response(JSON.stringify({ success: false, message: "⚠️ action غير معروفة — لازم تكون create أو rename أو delete أو setCapacity أو listDetailed" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    if (error instanceof AuthError) return authErrorResponse(error);
    console.error("❌ خطأ في manage-group:", error);
    const message = error instanceof Error ? error.message : "حدث خطأ داخلي في الخادم";
    return new Response(JSON.stringify({ success: false, message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

// supabase/functions/manage-registration-requests/index.ts
// ✅ إدارة طلبات الانضمام (جانب المدرس) — action: list | approve | reject
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
};

interface TokenPayload { sub: string; clientId?: string; teacherId?: string; role: string; name: string; }

class AuthError extends Error {
  status: number; code?: string;
  constructor(message: string, status = 401, code?: string) { super(message); this.status = status; this.code = code; }
}

async function verifyToken(req: Request): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw new AuthError("⚠️ التوكن مطلوب", 401);
  const token = authHeader.substring(7);
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) throw new Error("⚠️ JWT_SECRET غير مضبوط");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(JWT_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  try { return (await verify(token, key, "HS256")) as unknown as TokenPayload; }
  catch (_e) { throw new AuthError("⚠️ التوكن غير صالح أو منتهي الصلاحية", 401); }
}

function authErrorResponse(error: unknown) {
  const status = error instanceof AuthError ? error.status : 500;
  const code = error instanceof AuthError ? error.code : undefined;
  const message = error instanceof Error ? error.message : "⚠️ خطأ غير معروف";
  return new Response(JSON.stringify({ success: false, message, ...(code ? { code } : {}) }),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

// ✅ نفس مولّد كود UID مؤقت مستخدم في باقي النظام (حروف+أرقام)
function generateTempUid(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let uid = "";
  for (let i = 0; i < 8; i++) uid += chars.charAt(Math.floor(Math.random() * chars.length));
  return uid;
}

const ITERATIONS = 100_000;
function toHex(bytes: Uint8Array): string { return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join(""); }
async function pbkdf2(password: string, salt: Uint8Array, iterations: number): Promise<Uint8Array> {
  const keyMaterial = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, keyMaterial, 256);
  return new Uint8Array(bits);
}
async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hashBytes = await pbkdf2(password, salt, ITERATIONS);
  return `pbkdf2$${ITERATIONS}$${toHex(salt)}$${toHex(hashBytes)}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders, status: 200 });
  try {
    const payload = await verifyToken(req);
    if (payload.role !== "teacher" && payload.role !== "assistant") {
      return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const tokenClientId = payload.clientId || payload.teacherId;
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");

    const body = await req.json();
    const action = body.action;

    if (action === "list") {
      const { data, error } = await supabase.from("registration_requests").select("*").eq("teacher_id", tokenClientId).order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return new Response(JSON.stringify({ success: true, data: data || [] }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "reject") {
      const { requestId } = body;
      const { data: reqRow } = await supabase.from("registration_requests").select("teacher_id").eq("id", requestId).maybeSingle();
      if (!reqRow || reqRow.teacher_id !== tokenClientId) {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      await supabase.from("registration_requests").update({ status: "rejected", reviewed_at: new Date().toISOString() }).eq("id", requestId);
      return new Response(JSON.stringify({ success: true, message: "✅ تم رفض الطلب" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "approve") {
      const { requestId, groupName } = body;
      if (!groupName) {
        return new Response(JSON.stringify({ success: false, message: "⚠️ حدد المجموعة اللي هيتضاف لها الطالب" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { data: reqRow } = await supabase.from("registration_requests").select("*").eq("id", requestId).maybeSingle();
      if (!reqRow || reqRow.teacher_id !== tokenClientId) {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      if (reqRow.status !== "pending") {
        return new Response(JSON.stringify({ success: false, message: "⚠️ تم التعامل مع الطلب ده بالفعل" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // ✅ نتأكد إن ولي الأمر عنده حساب بالفعل، وإلا ننشئ واحد جديد (نفس منطق إضافة طالب عادي)
      const { data: existingParent } = await supabase.from("parents").select("phone").eq("phone", reqRow.parent_phone).maybeSingle();
      if (!existingParent) {
        const hashedPassword = await hashPassword(reqRow.parent_phone);
        await supabase.from("parents").insert({
          phone: reqRow.parent_phone, name: reqRow.parent_name || `ولي أمر ${reqRow.student_name}`,
          password_hash: hashedPassword, must_change_password: true, is_active: true,
        });
      }

      const uid = generateTempUid();
      const { error: insertError } = await supabase.from("students").insert({
        uid, name: reqRow.student_name, parent_phone: reqRow.parent_phone, group_name: groupName, teacher_id: tokenClientId,
      });
      if (insertError) {
        return new Response(JSON.stringify({ success: false, message: `⚠️ فشلت إضافة الطالب: ${insertError.message}` }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const { count } = await supabase.from("students").select("id", { count: "exact", head: true }).eq("teacher_id", tokenClientId);
      await supabase.from("teachers").update({ student_count: count }).eq("client_id", tokenClientId);

      await supabase.from("registration_requests").update({ status: "approved", reviewed_at: new Date().toISOString() }).eq("id", requestId);

      return new Response(JSON.stringify({ success: true, message: `✅ تم قبول الطلب وإضافة ${reqRow.student_name} بكود كارت مؤقت: ${uid}`, studentUid: uid }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ success: false, message: "⚠️ action غير معروفة" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    if (error instanceof AuthError) return authErrorResponse(error);
    const message = error instanceof Error ? error.message : "حدث خطأ داخلي";
    return new Response(JSON.stringify({ success: false, message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

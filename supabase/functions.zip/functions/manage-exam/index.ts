// supabase/functions/manage-exam/index.ts
// ✅ إدارة الاختبارات الإلكترونية (جانب المدرس) — action: create | addQuestion | deleteQuestion | publish | delete | list | getOne
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
};

interface TokenPayload { sub: string; clientId?: string; teacherId?: string; role: string; name: string; }

async function verifyToken(req: Request): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw new Error("⚠️ التوكن مطلوب");
  const token = authHeader.substring(7);
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) throw new Error("⚠️ JWT_SECRET غير مضبوط");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(JWT_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  return (await verify(token, key, "HS256")) as unknown as TokenPayload;
}

// ✅ تتأكد إن المدرس أصلاً مسموحله يستخدم ميزة الاختبارات الإلكترونية (صلاحية زي باقي الصلاحيات)
async function requireExamPermission(supabase: any, teacherId: string) {
  const { data: teacher } = await supabase.from("teachers").select("permissions").eq("client_id", teacherId).maybeSingle();
  const perms = teacher?.permissions || {};
  if (perms.can_create_exams !== true) {
    throw new Error("⛔ ميزة الاختبارات الإلكترونية غير متاحة في باقتك الحالية، تواصلي مع الإدارة لتفعيلها");
  }
}

// ✅ دالة مشتركة بين النشر اليدوي (فوري) والنشر المجدول (تلقائي) — بتحترم الطلاب المستهدفين
// لو محددين، وإلا بتبعت لكل طلاب المجموعة (السلوك الافتراضي القديم)
async function publishExamAndNotify(supabase: any, exam: any, teacherId: string): Promise<number> {
  await supabase.from("online_exams").update({ is_published: true }).eq("id", exam.id);

  const { data: teacher } = await supabase.from("teachers").select("name").eq("client_id", teacherId).maybeSingle();

  const { data: targets } = await supabase.from("exam_target_students").select("student_uid").eq("exam_id", exam.id);
  const targetUids = (targets || []).map((t: any) => t.student_uid);

  let studentsQuery = supabase.from("students").select("uid, parent_phone").eq("teacher_id", teacherId).eq("group_name", exam.group_name);
  if (targetUids.length > 0) studentsQuery = studentsQuery.in("uid", targetUids);
  const { data: students } = await studentsQuery;

  const notifRows = (students || []).filter((s: any) => s.parent_phone).map((s: any) => ({
    teacher_id: teacherId, parent_phone: s.parent_phone, student_uid: s.uid, type: "exam",
    title: "اختبار جديد", message: `اختبار "${exam.title}" جاهز الآن — مدته ${exam.duration_minutes} دقيقة${teacher?.name ? ` — مدرس ${teacher.name}` : ""}`,
    details: { exam_title: exam.title, exam_id: exam.id },
  }));
  if (notifRows.length > 0) await supabase.from("notifications").insert(notifRows);
  return notifRows.length;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const payload = await verifyToken(req);
    const tokenClientId = payload.clientId || payload.teacherId;
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");

    const body = await req.json();
    const action = body.action;

    // ✅ كل العمليات هنا (عدا list/getOne) محتاجة صلاحية إنشاء اختبارات
    if (["create", "addQuestion", "deleteQuestion", "publish", "delete", "setTargets"].includes(action)) {
      await requireExamPermission(supabase, tokenClientId!);
    }

    if (action === "create") {
      const { title, groupName, durationMinutes, scheduledAt } = body;
      if (!title || !groupName || !durationMinutes) {
        return new Response(JSON.stringify({ success: false, message: "⚠️ جميع الحقول مطلوبة" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      if (scheduledAt && new Date(scheduledAt).getTime() < Date.now()) {
        return new Response(JSON.stringify({ success: false, message: "⚠️ وقت الجدولة لازم يكون في المستقبل" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { data, error } = await supabase.from("online_exams").insert({
        teacher_id: tokenClientId, title, group_name: groupName, duration_minutes: Number(durationMinutes),
        scheduled_at: scheduledAt || null,
      }).select().single();
      if (error) throw new Error(error.message);
      return new Response(JSON.stringify({ success: true, message: "✅ تم إنشاء الاختبار، دلوقتي ضيفي الأسئلة", data }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "addQuestion") {
      const { examId, questionText, questionType, options, correctAnswer, points } = body;
      if (!examId || !questionText || !questionType || correctAnswer === undefined || !points) {
        return new Response(JSON.stringify({ success: false, message: "⚠️ جميع الحقول مطلوبة" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      if (!["mcq", "true_false"].includes(questionType)) {
        return new Response(JSON.stringify({ success: false, message: "⚠️ نوع السؤال غير صحيح" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      if (questionType === "mcq" && (!Array.isArray(options) || options.length < 2)) {
        return new Response(JSON.stringify({ success: false, message: "⚠️ الأسئلة الاختيارية محتاجة اختيارين على الأقل" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const { data: exam } = await supabase.from("online_exams").select("teacher_id").eq("id", examId).maybeSingle();
      if (!exam || exam.teacher_id !== tokenClientId) {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك بتعديل هذا الاختبار" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const { count } = await supabase.from("exam_questions").select("id", { count: "exact", head: true }).eq("exam_id", examId);

      const { data, error } = await supabase.from("exam_questions").insert({
        exam_id: examId, question_text: questionText, question_type: questionType,
        options: questionType === "mcq" ? options : null,
        correct_answer: String(correctAnswer), points: Number(points), order_index: count || 0,
      }).select().single();
      if (error) throw new Error(error.message);
      return new Response(JSON.stringify({ success: true, message: "✅ تم إضافة السؤال", data }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "deleteQuestion") {
      const { questionId } = body;
      const { data: q } = await supabase.from("exam_questions").select("exam_id, online_exams(teacher_id)").eq("id", questionId).maybeSingle();
      if (!q || (q as any).online_exams?.teacher_id !== tokenClientId) {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { error } = await supabase.from("exam_questions").delete().eq("id", questionId);
      if (error) throw new Error(error.message);
      return new Response(JSON.stringify({ success: true, message: "✅ تم حذف السؤال" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "setTargets") {
      const { examId, studentUids } = body; // studentUids: array — فاضية معناها "كل المجموعة"
      const { data: exam } = await supabase.from("online_exams").select("teacher_id, group_name").eq("id", examId).maybeSingle();
      if (!exam || exam.teacher_id !== tokenClientId) {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // ✅ نتأكد إن كل الطلاب المحددين فعلاً تابعين لنفس مجموعة الاختبار، قبل ما نسجّلهم كأهداف
      if (Array.isArray(studentUids) && studentUids.length > 0) {
        const { data: validStudents } = await supabase
          .from("students").select("uid").eq("teacher_id", tokenClientId).eq("group_name", exam.group_name).in("uid", studentUids);
        const validUids = new Set((validStudents || []).map((s: any) => s.uid));
        const invalidCount = studentUids.filter((u: string) => !validUids.has(u)).length;
        if (invalidCount > 0) {
          return new Response(JSON.stringify({ success: false, message: "⚠️ فيه طلاب محددين مش تابعين لمجموعة الاختبار" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
      }

      await supabase.from("exam_target_students").delete().eq("exam_id", examId);
      if (Array.isArray(studentUids) && studentUids.length > 0) {
        await supabase.from("exam_target_students").insert(studentUids.map((uid: string) => ({ exam_id: examId, student_uid: uid })));
      }

      const message = Array.isArray(studentUids) && studentUids.length > 0
        ? `✅ الاختبار دلوقتي هيتبعت لـ ${studentUids.length} طالب بس`
        : "✅ الاختبار دلوقتي هيتبعت لكل طلاب المجموعة";
      return new Response(JSON.stringify({ success: true, message }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "publish") {
      const { examId } = body;
      const { data: exam } = await supabase.from("online_exams").select("*").eq("id", examId).maybeSingle();
      if (!exam || exam.teacher_id !== tokenClientId) {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { count: qCount } = await supabase.from("exam_questions").select("id", { count: "exact", head: true }).eq("exam_id", examId);
      if (!qCount || qCount === 0) {
        return new Response(JSON.stringify({ success: false, message: "⚠️ لازم تضيفي سؤال واحد على الأقل قبل النشر" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // ✅ لو محدد وقت جدولة في المستقبل، منشرش دلوقتي — نستنى check-scheduled-exams تنشره في وقته
      if (exam.scheduled_at && new Date(exam.scheduled_at).getTime() > Date.now()) {
        return new Response(JSON.stringify({
          success: true,
          message: `✅ الاختبار مجدول للنشر تلقائياً في ${new Date(exam.scheduled_at).toLocaleString("ar-EG", { timeZone: "Africa/Cairo" })}`,
        }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const notifiedCount = await publishExamAndNotify(supabase, exam, tokenClientId!);
      return new Response(JSON.stringify({ success: true, message: `✅ تم نشر الاختبار وإرسال إشعار لـ ${notifiedCount} ولي أمر` }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "delete") {
      const { examId } = body;
      const { data: exam } = await supabase.from("online_exams").select("teacher_id").eq("id", examId).maybeSingle();
      if (!exam || exam.teacher_id !== tokenClientId) {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { error } = await supabase.from("online_exams").delete().eq("id", examId);
      if (error) throw new Error(error.message);
      return new Response(JSON.stringify({ success: true, message: "✅ تم حذف الاختبار" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "list") {
      const { data, error } = await supabase.from("online_exams").select("*, exam_questions(count)").eq("teacher_id", tokenClientId).order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return new Response(JSON.stringify({ success: true, data: data || [] }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "getOne") {
      const { examId } = body;
      const { data: exam } = await supabase.from("online_exams").select("*").eq("id", examId).maybeSingle();
      if (!exam || exam.teacher_id !== tokenClientId) {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      const { data: questions } = await supabase.from("exam_questions").select("*").eq("exam_id", examId).order("order_index");
      const { data: targets } = await supabase.from("exam_target_students").select("student_uid").eq("exam_id", examId);
      const { data: groupStudents } = await supabase.from("students").select("uid, name").eq("teacher_id", tokenClientId).eq("group_name", exam.group_name);
      return new Response(JSON.stringify({
        success: true,
        data: { ...exam, questions: questions || [], targetStudentUids: (targets || []).map((t: any) => t.student_uid), groupStudents: groupStudents || [] },
      }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ success: false, message: "⚠️ action غير معروفة" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "حدث خطأ داخلي";
    return new Response(JSON.stringify({ success: false, message }),
      { status: message.includes("⛔") ? 403 : 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

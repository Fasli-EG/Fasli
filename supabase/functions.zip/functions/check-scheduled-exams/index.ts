// supabase/functions/check-scheduled-exams/index.ts
// ✅ بتتنادى دورياً (كل ما حد فاتح لوحة التحكم أو صفحة الطالب) — بتنشر أي اختبار وصل وقت جدولته ولسه مانشرش
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
};

// ✅ نفس منطق النشر والإشعار المستخدم في manage-exam، بس مستقل هنا عشان الدالة دي ماتحتاجش توكن مدرس محدد
async function publishExamAndNotify(supabase: any, exam: any): Promise<number> {
  await supabase.from("online_exams").update({ is_published: true }).eq("id", exam.id);

  const { data: teacher } = await supabase.from("teachers").select("name").eq("client_id", exam.teacher_id).maybeSingle();
  const { data: targets } = await supabase.from("exam_target_students").select("student_uid").eq("exam_id", exam.id);
  const targetUids = (targets || []).map((t: any) => t.student_uid);

  let studentsQuery = supabase.from("students").select("uid, parent_phone").eq("teacher_id", exam.teacher_id).eq("group_name", exam.group_name);
  if (targetUids.length > 0) studentsQuery = studentsQuery.in("uid", targetUids);
  const { data: students } = await studentsQuery;

  const notifRows = (students || []).filter((s: any) => s.parent_phone).map((s: any) => ({
    teacher_id: exam.teacher_id, parent_phone: s.parent_phone, student_uid: s.uid, type: "exam",
    title: "اختبار جديد", message: `اختبار "${exam.title}" جاهز الآن — مدته ${exam.duration_minutes} دقيقة${teacher?.name ? ` — مدرس ${teacher.name}` : ""}`,
    details: { exam_title: exam.title, exam_id: exam.id },
  }));
  if (notifRows.length > 0) await supabase.from("notifications").insert(notifRows);
  return notifRows.length;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");

    const { data: dueExams } = await supabase
      .from("online_exams").select("*")
      .eq("is_published", false)
      .not("scheduled_at", "is", null)
      .lte("scheduled_at", new Date().toISOString());

    let publishedCount = 0;
    for (const exam of dueExams || []) {
      const { count: qCount } = await supabase.from("exam_questions").select("id", { count: "exact", head: true }).eq("exam_id", exam.id);
      if (!qCount || qCount === 0) continue; // اختبار فاضي من الأسئلة، منشرهوش لحد ما يتضاف له أسئلة
      await publishExamAndNotify(supabase, exam);
      publishedCount++;
    }

    return new Response(JSON.stringify({ success: true, publishedCount }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "حدث خطأ داخلي";
    return new Response(JSON.stringify({ success: false, message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

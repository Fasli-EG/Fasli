// supabase/functions/get-exams-for-student/index.ts
// ✅ بترجع للطالب كل الاختبارات المنشورة للمجموعة بتاعته، مع حالة كل واحد (لسه، جاري، خلص)
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
};

interface TokenPayload { sub: string; role: string; name: string; clientId?: string; }

async function verifyToken(req: Request): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw new Error("⚠️ التوكن مطلوب");
  const token = authHeader.substring(7);
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) throw new Error("⚠️ JWT_SECRET غير مضبوط");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(JWT_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  return (await verify(token, key, "HS256")) as unknown as TokenPayload;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const payload = await verifyToken(req);
    if (payload.role !== "student") {
      return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const studentUid = payload.sub;
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");

    const { data: student } = await supabase.from("students").select("group_name, teacher_id").eq("uid", studentUid).maybeSingle();
    if (!student) {
      return new Response(JSON.stringify({ success: false, message: "الطالب غير موجود" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { data: exams } = await supabase
      .from("online_exams").select("*, exam_questions(count)")
      .eq("teacher_id", student.teacher_id).eq("group_name", student.group_name).eq("is_published", true)
      .order("created_at", { ascending: false });

    // ✅ لو الاختبار محدد لطلاب معيّنين، الطالب ده لازم يكون من ضمنهم عشان يشوفه
    const examIds = (exams || []).map((e: any) => e.id);
    const { data: allTargets } = examIds.length > 0
      ? await supabase.from("exam_target_students").select("exam_id, student_uid").in("exam_id", examIds)
      : { data: [] };
    const targetsByExam: Record<number, Set<string>> = {};
    (allTargets || []).forEach((t: any) => {
      if (!targetsByExam[t.exam_id]) targetsByExam[t.exam_id] = new Set();
      targetsByExam[t.exam_id].add(t.student_uid);
    });
    const visibleExams = (exams || []).filter((e: any) => {
      const targets = targetsByExam[e.id];
      return !targets || targets.size === 0 || targets.has(studentUid);
    });

    // ✅ محاولات التدريب متعتبرش هنا خالص — الحالة/الدرجة المعروضة للطالب في القائمة
    // لازم تفضل بس مرآة للمحاولة الرسمية، حتى لو عنده محاولات تدريب كتير بعدها
    const { data: attempts } = await supabase
      .from("exam_attempts").select("*").eq("student_uid", studentUid).eq("mode", "official");

    const attemptsByExam: Record<number, any> = {};
    (attempts || []).forEach((a: any) => { attemptsByExam[a.exam_id] = a; });

    const result = visibleExams.map((e: any) => {
      const attempt = attemptsByExam[e.id];
      return {
        id: e.id, title: e.title, durationMinutes: e.duration_minutes,
        questionCount: e.exam_questions?.[0]?.count || 0,
        status: attempt ? attempt.status : "not_started",
        score: attempt?.score ?? null,
        totalPossible: attempt?.total_possible ?? null,
        // ✅ التدريب متاح دايماً على أي اختبار منشور وظاهر للطالب، حتى لو خلّص المحاولة الرسمية بالفعل
        canPractice: true,
      };
    });

    return new Response(JSON.stringify({ success: true, data: result }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "حدث خطأ داخلي";
    return new Response(JSON.stringify({ success: false, message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

// supabase/functions/card-action-mode/index.ts
// ✅ دالة موحّدة تجمع get-card-action-mode + set-card-action-mode — action: get | set
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
  "Access-Control-Max-Age": "86400",
};

interface TokenPayload { sub: string; clientId?: string; teacherId?: string; role: string; name: string; }

class AuthError extends Error {
  status: number; code?: string;
  constructor(message: string, status = 401, code?: string) { super(message); this.status = status; this.code = code; }
}

async function verifyToken(req: Request): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw new AuthError("⚠️ التوكن مطلوب", 401);
  const token = authHeader.substring(7);
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) throw new Error("⚠️ JWT_SECRET غير مضبوط");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(JWT_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  try { return (await verify(token, key, "HS256")) as unknown as TokenPayload; }
  catch (_e) { throw new AuthError("⚠️ التوكن غير صالح أو منتهي الصلاحية", 401); }
}

async function requireAssistantPermission(payload: TokenPayload, permKey: string): Promise<void> {
  if (payload.role !== "assistant") return;
  const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
  const { data: assistant } = await supabase.from("assistants").select("permissions").eq("id", payload.sub).maybeSingle();
  const perms = assistant?.permissions || {};
  if (perms[permKey] !== true) throw new AuthError("⛔ ليس لديك صلاحية لهذا الإجراء، تواصل مع المدرس", 403);
}

async function requireTeacherPlanPermission(clientId: string, permKey: string): Promise<void> {
  if (clientId === "master_admin") return;
  const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");
  const { data: teacher } = await supabase.from("teachers").select("permissions").eq("client_id", clientId).maybeSingle();
  const perms = teacher?.permissions || {};
  if (perms[permKey] === false) throw new AuthError("⛔ هذه الميزة غير متاحة في باقتك الحالية، تواصل مع الإدارة لتفعيلها", 403, "PLAN_RESTRICTED");
}

function authErrorResponse(error: unknown) {
  const status = error instanceof AuthError ? error.status : 500;
  const code = error instanceof AuthError ? error.code : undefined;
  const message = error instanceof Error ? error.message : "⚠️ خطأ غير معروف";
  return new Response(JSON.stringify({ success: false, message, ...(code ? { code } : {}) }),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

// ============================================
// ⭐ العملية 1: قراءة الوضع الحالي (مع الرجوع التلقائي لحضور بس بعد انتهاء المدة)
// ============================================
async function handleGet(supabase: any, tokenClientId: string) {
  const { data: mode } = await supabase.from("card_action_mode").select("*").eq("teacher_id", tokenClientId).maybeSingle();

  if (!mode || !mode.is_enabled) {
    return new Response(JSON.stringify({ success: true, readerEnabled: false, modes: [] }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const onlyAttendance = mode.attendance_enabled && !mode.payment_enabled && !mode.book_payment_enabled;
  if (onlyAttendance) {
    return new Response(JSON.stringify({ success: true, readerEnabled: true, modes: ["attendance"] }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const durationMs = (mode.duration_minutes || 30) * 60 * 1000;
  const idleMs = Date.now() - new Date(mode.set_at || mode.updated_at).getTime();
  if (idleMs > durationMs) {
    await supabase.from("card_action_mode").update({
      attendance_enabled: true, payment_enabled: false, book_payment_enabled: false,
      updated_at: new Date().toISOString(),
    }).eq("teacher_id", tokenClientId);
    return new Response(JSON.stringify({ success: true, readerEnabled: true, modes: ["attendance"], autoReverted: true }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const activeModes = [];
  if (mode.attendance_enabled) activeModes.push("attendance");
  if (mode.payment_enabled) activeModes.push("payment");
  if (mode.book_payment_enabled) activeModes.push("book_payment");

  return new Response(JSON.stringify({
    success: true, readerEnabled: true, modes: activeModes,
    paymentTitle: mode.payment_title, paymentAmount: mode.payment_amount,
    bookId: mode.book_id, bookAmount: mode.book_amount, setBy: mode.set_by,
    remainingSeconds: Math.max(0, Math.round((durationMs - idleMs) / 1000)),
  }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

// ============================================
// ⭐ العملية 2: تحديد الوضع (تفعيل/تعطيل القارئ، أو تحديد الأوضاع النشطة)
// ============================================
async function handleSet(supabase: any, payload: TokenPayload, tokenClientId: string, body: any) {
  const { modes, paymentTitle, paymentAmount, bookId, bookAmount, isEnabled, durationMinutes } = body;

  if (isEnabled === false) {
    const { error: disableError } = await supabase.from("card_action_mode").upsert({
      teacher_id: tokenClientId, is_enabled: false, updated_at: new Date().toISOString(),
    }, { onConflict: "teacher_id" });
    if (disableError) {
      return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    return new Response(JSON.stringify({ success: true, message: "⏸ تم إيقاف القارئ" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const attendanceEnabled = Array.isArray(modes) ? modes.includes("attendance") : true;
  const paymentEnabled = Array.isArray(modes) && modes.includes("payment");
  const bookPaymentEnabled = Array.isArray(modes) && modes.includes("book_payment");

  if (!attendanceEnabled && !paymentEnabled && !bookPaymentEnabled) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ اختر وضع واحد على الأقل" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  if (paymentEnabled && (!paymentTitle || paymentAmount === undefined)) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ اختر بند السداد والمبلغ" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  if (bookPaymentEnabled && (!bookId || bookAmount === undefined)) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ اختر المذكرة والمبلغ" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  const finalDuration = durationMinutes && Number(durationMinutes) > 0 ? Number(durationMinutes) : 30;
  const setByName = payload.name || (payload.role === "assistant" ? "مساعد" : "مدرس");

  const { error } = await supabase.from("card_action_mode").upsert({
    teacher_id: tokenClientId, is_enabled: true,
    attendance_enabled: attendanceEnabled, payment_enabled: paymentEnabled, book_payment_enabled: bookPaymentEnabled,
    payment_title: paymentEnabled ? paymentTitle : null, payment_amount: paymentEnabled ? Number(paymentAmount) : null,
    book_id: bookPaymentEnabled ? bookId : null, book_amount: bookPaymentEnabled ? Number(bookAmount) : null,
    duration_minutes: finalDuration, set_by: setByName, set_at: new Date().toISOString(), updated_at: new Date().toISOString(),
  }, { onConflict: "teacher_id" });

  if (error) {
    console.error("❌ فشل تحديد وضع الكارت:", error);
    return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const activeLabels = [];
  if (attendanceEnabled) activeLabels.push("تسجيل الحضور");
  if (paymentEnabled) activeLabels.push("دفع اشتراك");
  if (bookPaymentEnabled) activeLabels.push("سداد مذكرة");

  return new Response(JSON.stringify({ success: true, message: `✅ الكارت دلوقتي شغّال على: ${activeLabels.join(" + ")} لمدة ${finalDuration} دقيقة، وبعدها هيرجع لوضع الحضور بس تلقائياً` }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });
  try {
    const payload = await verifyToken(req);
    const tokenClientId = payload.clientId || payload.teacherId;
    if ((payload.role !== "teacher" && payload.role !== "assistant") || !tokenClientId) {
      return new Response(JSON.stringify({ success: false, message: "⛔ متاح للمدرس أو المساعد بس" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } });

    const body = await req.json();
    const action = body.action;

    if (action === "get") {
      await requireAssistantPermission(payload, "manage_card_mode");
      return await handleGet(supabase, tokenClientId);
    }
    if (action === "set") {
      await requireTeacherPlanPermission(tokenClientId, "can_use_rfid");
      await requireAssistantPermission(payload, "manage_card_mode");
      return await handleSet(supabase, payload, tokenClientId, body);
    }

    return new Response(JSON.stringify({ success: false, message: "⚠️ action غير معروفة" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    if (error instanceof AuthError) return authErrorResponse(error);
    console.error("❌ خطأ غير متوقع:", error);
    return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

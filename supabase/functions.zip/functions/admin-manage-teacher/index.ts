// supabase/functions/admin-manage-teacher/index.ts
// ✅ دالة موحّدة تجمع admin-add-teacher + admin-update-teacher + admin-delete-teacher بـ "action" parameter
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
  "Access-Control-Max-Age": "86400",
};

export interface TokenPayload {
  sub: string; clientId?: string; teacherId?: string; role: "teacher" | "assistant" | "parent"; name: string; exp: number;
}

export class AuthError extends Error {
  status: number; code?: string;
  constructor(message: string, status = 401, code?: string) { super(message); this.status = status; this.code = code; }
}

async function getKey() {
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) throw new Error("⚠️ JWT_SECRET غير مضبوط في متغيرات البيئة");
  return await crypto.subtle.importKey("raw", new TextEncoder().encode(JWT_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
}

export async function verifyToken(req: Request): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) throw new AuthError("⚠️ التوكن مطلوب", 401);
  const token = authHeader.substring(7);
  const key = await getKey();
  try { return (await verify(token, key, "HS256")) as unknown as TokenPayload; }
  catch (_e) { throw new AuthError("⚠️ التوكن غير صالح أو منتهي الصلاحية", 401); }
}

export function requireAdmin(payload: TokenPayload) {
  if (payload.role !== "teacher" || payload.clientId !== "master_admin") {
    throw new AuthError("⛔ غير مصرح بهذه العملية", 403);
  }
}

export function authErrorResponse(error: unknown) {
  const status = error instanceof AuthError ? error.status : 500;
  const code = error instanceof AuthError ? error.code : undefined;
  const message = error instanceof Error ? error.message : "⚠️ خطأ غير معروف";
  return new Response(JSON.stringify({ success: false, message, ...(code ? { code } : {}) }),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

const ITERATIONS = 100_000;
function toHex(bytes: Uint8Array): string { return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join(""); }
async function pbkdf2(password: string, salt: Uint8Array, iterations: number): Promise<Uint8Array> {
  const keyMaterial = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, keyMaterial, 256);
  return new Uint8Array(bits);
}
async function hashPassword(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hashBytes = await pbkdf2(password, salt, ITERATIONS);
  return `pbkdf2$${ITERATIONS}$${toHex(salt)}$${toHex(hashBytes)}`;
}

// ============================================
// ⭐ العملية 1: إضافة مدرس (منطق admin-add-teacher الأصلي كامل)
// ============================================
async function handleAdd(supabase: any, body: any) {
  const { clientId, name, expiryDate, maxStudents, maxAssistants, permissions } = body;
  if (!clientId || !name) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ جميع الحقول مطلوبة" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  if (clientId === "master_admin") {
    return new Response(JSON.stringify({ success: false, message: "⛔ لا يمكن إضافة حساب المشرف الرئيسي" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const { data: existing } = await supabase.from("teachers").select("client_id").eq("client_id", clientId).maybeSingle();
  if (existing) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ هذا الكود موجود بالفعل" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const finalExpiryDate = expiryDate || null;
  const defaultHash = await hashPassword(clientId);
  const deviceSecretBytes = crypto.getRandomValues(new Uint8Array(16));
  const deviceSecret = Array.from(deviceSecretBytes).map((b) => b.toString(16).padStart(2, "0")).join("");

  const { data, error } = await supabase.from("teachers").insert({
    client_id: clientId, name, password_hash: defaultHash, must_change_password: true, is_active: true,
    expiry_date: finalExpiryDate, max_students: maxStudents || 0,
    max_assistants: maxAssistants !== undefined && maxAssistants !== null ? maxAssistants : 3,
    student_count: 0, device_secret: deviceSecret,
    permissions: permissions || {
      can_manage_students: true, can_manage_groups: true, can_manage_grades: true, can_manage_payments: true,
      can_manage_books: true, can_send_messages: true, can_view_reports: true, can_view_financial: true,
      can_use_backup: true, can_manage_assistants: true, can_use_rfid: true,
    }
  }).select();

  if (error) {
    return new Response(JSON.stringify({ success: false, message: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  return new Response(JSON.stringify({
    success: true,
    message: `✅ تم إضافة المدرس ${name} بنجاح${finalExpiryDate ? ` (صلاحية حتى ${finalExpiryDate})` : " (صلاحية غير محدودة)"}`,
    data
  }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

// ============================================
// ⭐ العملية 2: تعديل مدرس (منطق admin-update-teacher الأصلي كامل)
// ============================================
async function handleUpdate(supabase: any, body: any) {
  const { clientId, name, isActive: isActiveParam, expiryDate, maxStudents, maxAssistants, permissions, notes } = body;
  if (!clientId || !name) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ جميع الحقول مطلوبة" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  if (clientId === "master_admin") {
    return new Response(JSON.stringify({ success: false, message: "⛔ لا يمكن تعديل حساب المشرف الرئيسي" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  let calculatedIsActive = isActiveParam;
  if (expiryDate) {
    const today = new Date().toISOString().split("T")[0];
    calculatedIsActive = expiryDate >= today;
  }

  const { data: oldTeacher } = await supabase.from("teachers").select("name, is_active, expiry_date, max_students, permissions").eq("client_id", clientId).maybeSingle();

  const updateData: any = {
    name, max_students: maxStudents || 0,
    max_assistants: maxAssistants !== undefined && maxAssistants !== null ? maxAssistants : 3,
    permissions, notes: notes || null, is_active: calculatedIsActive, expiry_date: expiryDate || null,
  };

  const { error } = await supabase.from("teachers").update(updateData).eq("client_id", clientId);
  if (error) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const { data: updatedTeacher } = await supabase.from("teachers").select("*").eq("client_id", clientId).maybeSingle();

  const changes: any = {};
  if (oldTeacher) {
    if (oldTeacher.name !== name) changes.name = { old: oldTeacher.name, new: name };
    if (oldTeacher.is_active !== calculatedIsActive) changes.is_active = { old: oldTeacher.is_active, new: calculatedIsActive };
    if (oldTeacher.expiry_date !== (expiryDate || null)) changes.expiry_date = { old: oldTeacher.expiry_date, new: expiryDate || null };
    if (oldTeacher.max_students !== (maxStudents || 0)) changes.max_students = { old: oldTeacher.max_students, new: maxStudents || 0 };
    if (JSON.stringify(oldTeacher.permissions) !== JSON.stringify(permissions)) changes.permissions = { old: oldTeacher.permissions, new: permissions };
  }

  let statusMessage = "✅ تم تحديث بيانات المدرس بنجاح";
  if (expiryDate) {
    const today = new Date().toISOString().split("T")[0];
    if (expiryDate < today) {
      statusMessage += " (⚠️ الترخيص منتهي الصلاحية)";
    } else {
      const daysRemaining = Math.ceil((new Date(expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
      statusMessage += ` (📅 متبقي ${daysRemaining} يوم)`;
    }
  } else {
    statusMessage += " (♾️ صلاحية غير محدودة)";
  }

  return new Response(JSON.stringify({ success: true, message: statusMessage, data: updatedTeacher || null }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

// ============================================
// ⭐ العملية 3: حذف مدرس (منطق admin-delete-teacher الأصلي كامل — بنفس ترتيب الحذف بالظبط)
// ============================================
async function handleDelete(supabase: any, body: any) {
  const { clientId } = body;
  if (!clientId) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ clientId مطلوب" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  if (clientId === "master_admin") {
    return new Response(JSON.stringify({ success: false, message: "⛔ لا يمكن حذف حساب المشرف الرئيسي" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const { data: teacher } = await supabase.from("teachers").select("client_id").eq("client_id", clientId).maybeSingle();
  if (!teacher) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ المدرس غير موجود" }),
      { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  await supabase.from("grades").delete().eq("teacher_id", clientId);
  await supabase.from("payments").delete().eq("teacher_id", clientId);
  await supabase.from("book_payments").delete().eq("teacher_id", clientId);
  await supabase.from("attendance").delete().eq("teacher_id", clientId);

  await supabase.from("system_cards").delete().eq("teacher_id", clientId);
  await supabase.from("pending_card_registrations").delete().eq("teacher_id", clientId);

  const { data: students } = await supabase.from("students").select("uid, parent_phone").eq("teacher_id", clientId);
  await supabase.from("students").delete().eq("teacher_id", clientId);

  const parentPhones = [...new Set((students || []).map((s: any) => s.parent_phone).filter(Boolean))];
  for (const phone of parentPhones) {
    const { count } = await supabase.from("students").select("id", { count: "exact", head: true }).eq("parent_phone", phone);
    if (!count || count === 0) await supabase.from("parents").delete().eq("phone", phone);
  }

  await supabase.from("assistants").delete().eq("teacher_id", clientId);
  await supabase.from("groups").delete().eq("teacher_id", clientId);
  await supabase.from("books").delete().eq("teacher_id", clientId);
  await supabase.from("payment_titles").delete().eq("teacher_id", clientId);
  await supabase.from("exam_titles").delete().eq("teacher_id", clientId);

  await supabase.from("notifications").delete().eq("teacher_id", clientId);
  await supabase.from("push_tokens").delete().eq("recipient_type", "teacher").eq("recipient_id", clientId);
  await supabase.from("activity_logs").delete().eq("teacher_id", clientId);

  const { error } = await supabase.from("teachers").delete().eq("client_id", clientId);
  if (error) {
    return new Response(JSON.stringify({ success: false, message: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  return new Response(JSON.stringify({ success: true, message: "✅ تم حذف المدرس وجميع بياناته المرتبطة بنجاح" }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders, status: 200 });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ success: false, message: "⚠️ الطريقة غير مسموحة" }),
      { status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  try {
    const payload = await verifyToken(req);
    requireAdmin(payload);

    const supabaseUrl = Deno.env.get("SUPABASE_URL") || Deno.env.get("DATABASE_URL") || "";
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SERVICE_ROLE") || "";
    if (!supabaseKey) throw new Error("⚠️ SERVICE_ROLE غير مضبوط في متغيرات البيئة");
    const supabase = createClient(supabaseUrl, supabaseKey);

    let body: any;
    try { body = await req.json(); }
    catch (_e) {
      return new Response(JSON.stringify({ success: false, message: "الطلب يجب أن يحتوي على JSON صالح" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const action = body.action;
    if (action === "add") return await handleAdd(supabase, body);
    if (action === "update") return await handleUpdate(supabase, body);
    if (action === "delete") return await handleDelete(supabase, body);

    return new Response(JSON.stringify({ success: false, message: "⚠️ action غير معروفة — لازم تكون add أو update أو delete" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    if (error instanceof AuthError) return authErrorResponse(error);
    const message = error instanceof Error ? error.message : "حدث خطأ داخلي في الخادم";
    return new Response(JSON.stringify({ success: false, message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

// supabase/functions/submit-registration-request/index.ts
// ✅ دالة عامة (بدون توكن) — أي حد يقدر يقدّم طلب انضمام من رابط عام للمدرس، من غير تسجيل دخول
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, apikey, x-client-info",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders, status: 200 });
  try {
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");

    const { teacherId, studentName, parentName, parentPhone, requestedGroup, notes } = await req.json();

    if (!teacherId || !studentName || !parentPhone) {
      return new Response(JSON.stringify({ success: false, message: "⚠️ الاسم ورقم الهاتف مطلوبين" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // ✅ نتأكد إن رابط المدرس ده فعلاً موجود ومفعّل، قبل ما نقبل أي طلب عليه
    const { data: teacher } = await supabase.from("teachers").select("client_id, name, is_active").eq("client_id", teacherId).maybeSingle();
    if (!teacher || !teacher.is_active) {
      return new Response(JSON.stringify({ success: false, message: "⚠️ رابط التسجيل ده مش متاح حالياً" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // ✅ حماية بسيطة من التكرار: نفس رقم الهاتف بنفس اسم الطالب عند نفس المدرس، لو فيه طلب معلّق أو قائمة انتظار بالفعل مانكررهوش
    const { data: existing } = await supabase.from("registration_requests")
      .select("id").eq("teacher_id", teacherId).eq("parent_phone", parentPhone).eq("student_name", studentName).in("status", ["pending", "waitlisted"]).maybeSingle();
    if (existing) {
      return new Response(JSON.stringify({ success: false, message: "⚠️ عندك طلب معلّق بالفعل بنفس البيانات، استني رد المدرس" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // ✅ لو المجموعة المطلوبة عندها حد أقصى للطلاب ووصلت له، الطلب بيتسجل كـ"قائمة انتظار" بدل "معلّق"
    // — المدرس بيشوفه في قائمة منفصلة ويقدر يقبله يدوياً وقت ما يفضى مكان أو يوسّع الحد
    let isWaitlisted = false;
    if (requestedGroup) {
      const { data: groupRow } = await supabase.from("groups").select("max_students").eq("teacher_id", teacherId).eq("name", requestedGroup).maybeSingle();
      const maxStudents = groupRow?.max_students ?? null;
      if (maxStudents !== null) {
        const { count } = await supabase.from("students").select("id", { count: "exact", head: true }).eq("teacher_id", teacherId).eq("group_name", requestedGroup);
        if ((count || 0) >= maxStudents) isWaitlisted = true;
      }
    }

    const { error } = await supabase.from("registration_requests").insert({
      teacher_id: teacherId, student_name: studentName, parent_name: parentName || null,
      parent_phone: parentPhone, requested_group: requestedGroup || null, notes: notes || null,
      status: isWaitlisted ? "waitlisted" : "pending",
    });
    if (error) throw new Error(error.message);

    const message = isWaitlisted
      ? `📋 المجموعة المطلوبة كاملة العدد حالياً، فتم تسجيلك في قائمة الانتظار وهيتم التواصل معاك من مدرس ${teacher.name} أول ما يفضى مكان`
      : `✅ تم إرسال طلبك بنجاح، وهيتم التواصل معاك من مدرس ${teacher.name} قريباً`;

    return new Response(JSON.stringify({ success: true, message, waitlisted: isWaitlisted }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "حدث خطأ داخلي";
    return new Response(JSON.stringify({ success: false, message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

// supabase/functions/record-attendance/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// ============================================
// (من _shared/auth.ts — مدموج مباشرة لأن Dashboard لا يدعم الاستيراد بين الدوال)
// ============================================
// ============================================
// موديول موحّد للتحقق من هوية المستخدم (JWT)
// يُستورد في كل دالة تحتاج تأكيد هوية بدل تكرار الكود
// ============================================
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
  "Access-Control-Max-Age": "86400",
};

export interface TokenPayload {
  sub: string;
  clientId?: string;
  teacherId?: string;
  username?: string;
  phone?: string;
  role: "teacher" | "assistant" | "parent";
  name: string;
  exp: number;
}

export class AuthError extends Error {
  status: number;
  code?: string;
  constructor(message: string, status = 401, code?: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

async function getKey() {
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) {
    throw new Error("⚠️ JWT_SECRET غير مضبوط في متغيرات البيئة");
  }
  return await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(JWT_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["verify"]
  );
}

/** عميل Supabase بصلاحيات كاملة، مخصص لفحص الترخيص فقط (بدون تكرار الاستيراد في كل دالة) */
async function licenseCheckClient() {
  const { createClient } = await import("https://esm.sh/@supabase/supabase-js@2.38.4");
  const url = Deno.env.get("DATABASE_URL") || Deno.env.get("SUPABASE_URL") || "";
  const key = Deno.env.get("SERVICE_ROLE") || Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  return createClient(url, key, { auth: { autoRefreshToken: false, persistSession: false } });
}

/**
 * يتحقق من حالة ترخيص المدرس (نشط + لم تنتهِ صلاحيته).
 * يُستخدم تلقائياً جوه verifyToken لكل توكن مدرس/مساعد، فيغطي المساعدين تلقائياً
 * (توكن المساعد بيتحقق من ترخيص المدرس بتاعه نفسه).
 */
async function checkLicenseActive(teacherClientId: string): Promise<{ active: boolean; reason?: string }> {
  if (teacherClientId === "master_admin") return { active: true };

  const supabase = await licenseCheckClient();
  const { data: teacher, error } = await supabase
    .from("teachers")
    .select("is_active, expiry_date")
    .eq("client_id", teacherClientId)
    .maybeSingle();

  if (error || !teacher) return { active: false, reason: "الحساب غير موجود" };
  if (teacher.is_active === false) return { active: false, reason: "الحساب معطّل" };

  if (teacher.expiry_date) {
    const todayCLA = new Date().toISOString().split("T")[0];
    if (teacher.expiry_date < todayCLA) return { active: false, reason: "انتهت صلاحية الترخيص" };
  }

  return { active: true };
}

/**
 * يتحقق من صحة الـ Authorization header ويرجّع بيانات التوكن.
 * يرمي AuthError (401) لو التوكن غير موجود/غير صالح/منتهي.
 * يرمي AuthError (402, code=LICENSE_EXPIRED) لو ترخيص المدرس (أو مدرس المساعد) منتهي/معطّل.
 * مرّر skipLicenseCheck:true فقط للدوال العامة اللي المفروض تشتغل حتى لو الترخيص منتهي (نادر جداً).
 */
export async function verifyToken(req: Request, opts?: { skipLicenseCheck?: boolean }): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    throw new AuthError("⚠️ التوكن مطلوب", 401);
  }
  const token = authHeader.substring(7);
  const key = await getKey();
  let payload: TokenPayload;
  try {
    payload = (await verify(token, key, "HS256")) as unknown as TokenPayload;
  } catch (_e) {
    throw new AuthError("⚠️ التوكن غير صالح أو منتهي الصلاحية", 401);
  }

  if (!opts?.skipLicenseCheck && (payload.role === "teacher" || payload.role === "assistant")) {
    const ownerId = payload.clientId || payload.teacherId;
    if (ownerId) {
      const license = await checkLicenseActive(ownerId);
      if (!license.active) {
        throw new AuthError(
          `⛔ ${license.reason || "انتهت صلاحية الترخيص"} — يرجى التواصل مع الإدارة`,
          402,
          "LICENSE_EXPIRED"
        );
      }
    }
  }

  return payload;
}

/**
 * يتحقق من هوية جهاز قارئ الكروت (ESP32) عن طريق سر خاص بكل مدرس،
 * بديل عن التوكن العادي لأن الجهاز مش عنده تسجيل دخول. يرجّع بيانات المدرس لو صح.
 */
export async function verifyDeviceSecret(clientId: string, deviceSecret: string): Promise<void> {
  if (!clientId || !deviceSecret) {
    throw new AuthError("⚠️ بيانات الجهاز ناقصة (clientId أو deviceSecret)", 401);
  }
  const supabase = await licenseCheckClient();
  const { data: teacher, error } = await supabase
    .from("teachers")
    .select("device_secret, is_active, expiry_date")
    .eq("client_id", clientId)
    .maybeSingle();

  if (error || !teacher || !teacher.device_secret) {
    throw new AuthError("⛔ جهاز غير معروف", 401);
  }
  if (teacher.device_secret !== deviceSecret) {
    throw new AuthError("⛔ سر الجهاز غير صحيح", 401);
  }
  if (teacher.is_active === false) {
    throw new AuthError("⛔ حساب المدرس معطّل", 402, "LICENSE_EXPIRED");
  }
  if (teacher.expiry_date) {
    const today = new Date().toISOString().split("T")[0];
    if (teacher.expiry_date < today) {
      throw new AuthError("⛔ انتهت صلاحية الترخيص", 402, "LICENSE_EXPIRED");
    }
  }
}

/** يرجّع معرّف "المدرس المالك" للحساب (نفس clientId للمدرس، أو teacherId للمساعد) */
export function ownerClientId(payload: TokenPayload): string {
  const id = payload.clientId || payload.teacherId;
  if (!id) throw new AuthError("⚠️ التوكن لا يحتوي على clientId", 401);
  return id;
}

/** يتأكد إن التوكن (مدرس أو مساعد تابع له) مصرح له بالوصول لبيانات clientId المطلوب */
export function requireOwnClientId(payload: TokenPayload, requestedClientId?: string | null) {
  const tokenClientId = ownerClientId(payload);
  if (requestedClientId && requestedClientId !== tokenClientId) {
    throw new AuthError("⛔ غير مصرح لك بمشاهدة بيانات هذا المدرس", 403);
  }
  return tokenClientId;
}

/** يتأكد إن التوكن ده لحساب المشرف الرئيسي (master_admin) */
export function requireAdmin(payload: TokenPayload) {
  if (payload.role !== "teacher" || payload.clientId !== "master_admin") {
    throw new AuthError("⛔ غير مصرح بهذه العملية", 403);
  }
}

/** يتأكد إن التوكن لحساب ولي أمر برقم هاتف محدد */
export function requireParentPhone(payload: TokenPayload, requestedPhone?: string | null) {
  if (payload.role !== "parent" || !payload.phone) {
    throw new AuthError("⛔ غير مصرح بهذه العملية", 403);
  }
  if (requestedPhone && requestedPhone !== payload.phone) {
    throw new AuthError("⛔ غير مصرح لك بمشاهدة بيانات هذا الطالب", 403);
  }
  return payload.phone;
}

/**
 * يتأكد إن باقة المدرس (المُحدّدة من الأدمن) فيها الميزة المطلوبة.
 * لو المفتاح مش موجود في permissions (مدرس قديم قبل إضافة الميزة دي) بنسمح افتراضياً (توافق مع الحسابات القديمة).
 * لا تُستدعى لحساب master_admin.
 */
export async function requireTeacherPlanPermission(clientId: string, permKey: string): Promise<void> {
  if (clientId === "master_admin") return;
  const supabase = await licenseCheckClient();
  const { data: teacher } = await supabase
    .from("teachers").select("permissions").eq("client_id", clientId).maybeSingle();
  const perms = teacher?.permissions || {};
  if (perms[permKey] === false) {
    throw new AuthError("⛔ هذه الميزة غير متاحة في باقتك الحالية، تواصل مع الإدارة لتفعيلها", 403, "PLAN_RESTRICTED");
  }
}

/**
 * يتأكد إن المساعد عنده صلاحية محددة منحها له المدرس. لا تأثير على المدرس نفسه (دايماً مسموح له).
 */
export async function requireAssistantPermission(payload: TokenPayload, permKey: string): Promise<void> {
  if (payload.role !== "assistant") return;
  const supabase = await licenseCheckClient();
  const { data: assistant } = await supabase
    .from("assistants").select("permissions").eq("id", payload.sub).maybeSingle();
  const perms = assistant?.permissions || {};
  if (perms[permKey] !== true) {
    throw new AuthError("⛔ ليس لديك صلاحية لهذا الإجراء، تواصل مع المدرس", 403);
  }
}

/** يحوّل AuthError لـ Response جاهزة */
export function authErrorResponse(error: unknown) {
  const status = error instanceof AuthError ? error.status : 500;
  const code = error instanceof AuthError ? error.code : undefined;
  const message = error instanceof Error ? error.message : "⚠️ خطأ غير معروف";
  return new Response(
    JSON.stringify({ success: false, message, ...(code ? { code } : {}) }),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
  );
}

// ============================================
// (من _shared/push.ts — مدموج مباشرة لأن Dashboard لا يدعم الاستيراد بين الدوال)
// ============================================
// إرسال إشعارات Push حقيقية عبر Firebase Cloud Messaging (HTTP v1 API)
// محتاج متغير بيئة اسمه FIREBASE_SERVICE_ACCOUNT فيه محتوى ملف الـ Service Account JSON كامل كنص

interface ServiceAccount {
  client_email: string;
  private_key: string;
  project_id: string;
}

let cachedAccessToken: { token: string; expiresAt: number } | null = null;

function base64url(input: ArrayBuffer | string): string {
  let bytes: Uint8Array;
  if (typeof input === "string") {
    bytes = new TextEncoder().encode(input);
  } else {
    bytes = new Uint8Array(input);
  }
  let binary = "";
  bytes.forEach((b) => (binary += String.fromCharCode(b)));
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function getAccessToken(sa: ServiceAccount): Promise<string> {
  if (cachedAccessToken && cachedAccessToken.expiresAt > Date.now() + 60_000) {
    return cachedAccessToken.token;
  }

  const now = Math.floor(Date.now() / 1000);
  const header = { alg: "RS256", typ: "JWT" };
  const claims = {
    iss: sa.client_email,
    scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now,
  };

  const unsigned = `${base64url(JSON.stringify(header))}.${base64url(JSON.stringify(claims))}`;

  // ✅ نجهّز المفتاح الخاص للتوقيع (PEM -> CryptoKey)
  const pemBody = sa.private_key
    .replace(/-----BEGIN PRIVATE KEY-----/, "")
    .replace(/-----END PRIVATE KEY-----/, "")
    .replace(/\s/g, "");
  const binaryKey = Uint8Array.from(atob(pemBody), (c) => c.charCodeAt(0));

  const cryptoKey = await crypto.subtle.importKey(
    "pkcs8",
    binaryKey.buffer,
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  );

  const signature = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", cryptoKey, new TextEncoder().encode(unsigned));
  const jwt = `${unsigned}.${base64url(signature)}`;

  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt,
    }),
  });

  const tokenData = await tokenRes.json();
  if (!tokenRes.ok || !tokenData.access_token) {
    console.error("❌ فشل الحصول على access token من Firebase:", tokenData);
    throw new Error("فشل مصادقة Firebase");
  }

  cachedAccessToken = { token: tokenData.access_token, expiresAt: Date.now() + tokenData.expires_in * 1000 };
  return tokenData.access_token;
}

/**
 * يبعت إشعار Push حقيقي لكل الأجهزة المسجّلة لمستخدم معيّن (ولي أمر أو مساعد أو مدرس).
 * أي فشل هنا بيتسجّل في السيرفر بس، ومايوقفش العملية الأساسية (زي تسجيل حضور أو دفعة).
 */
export async function sendPushToRecipient(
  supabase: any,
  recipientType: "parent" | "assistant" | "teacher",
  recipientId: string,
  title: string,
  body: string
): Promise<void> {
  try {
    const saJson = Deno.env.get("FIREBASE_SERVICE_ACCOUNT");
    if (!saJson) return; // Firebase لسه مش متفعّل، نتجاهل بهدوء

    const { data: tokens } = await supabase
      .from("push_tokens")
      .select("id, token")
      .eq("recipient_type", recipientType)
      .eq("recipient_id", recipientId);

    if (!tokens || tokens.length === 0) return;

    const sa: ServiceAccount = JSON.parse(saJson);
    const accessToken = await getAccessToken(sa);

    for (const row of tokens) {
      const res = await fetch(
        `https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`,
        {
          method: "POST",
          headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json" },
          body: JSON.stringify({
            message: {
              token: row.token,
              notification: { title, body },
              android: { priority: "high", notification: { sound: "default", channel_id: "fasli_notifications" } },
            },
          }),
        }
      );

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        // ✅ لو التوكن بقى غير صالح (اتفصل التطبيق أو اتمسح)، نمسحه من القائمة عشان منحاولش نبعتله تاني
        if (errData?.error?.status === "NOT_FOUND" || errData?.error?.status === "INVALID_ARGUMENT") {
          await supabase.from("push_tokens").delete().eq("id", row.id);
        } else {
          console.error("⚠️ فشل إرسال Push notification:", errData);
        }
      }
    }
  } catch (error) {
    console.error("⚠️ خطأ غير متوقع في إرسال Push notification:", error);
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    const { clientId, uid, secret, manual, notes, assistantId } = await req.json();

    if (!clientId || !uid) {
      return new Response(
        JSON.stringify({ success: false, message: "clientId و uid مطلوبان" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // ✅ رسائل عمليات إضافية (دفع/سداد مذكرة) اللي حصلت مع الحضور في نفس المسحة، لو الوضع مفعّل
    const extraActionMessages: string[] = [];

    // ✅ مصدر الطلب: إما جهاز قارئ كروت (بسر خاص بالمدرس) أو مستخدم مسجل دخول عادي (توكن)
    if (secret) {
      await verifyDeviceSecret(clientId, secret);
      await requireTeacherPlanPermission(clientId, "can_use_rfid");

      // ✅ لو المدرس/المساعد فاتح وضع "قراءة كارت" في قسم إضافة طالب أو ربط كارت دلوقتي،
      // أي كارت يتمرّغ في الوقت ده لازم يتجاهل تسجيل الحضور خالص — هو بيتفحص بس، مش بيحضر فعلياً
      const { data: activeSession } = await supabase
        .from("pending_card_registrations").select("id, requested_at").eq("teacher_id", clientId).maybeSingle();

      // ✅ بنحسب الفرق بالثواني، عشان نضمن الحماية تفضل شغّالة حتى لو الواجهة نضّفت الصف بسرعة
      // (فرق التوقيت بين الطلبين اللي بيبعتهم البورد ممكن ياخد كذا ثانية بسبب زمن استجابة الشبكة)
      const isRecentSession = activeSession?.requested_at
        ? (Date.now() - new Date(activeSession.requested_at).getTime()) < 20000
        : false;

      if (activeSession && isRecentSession) {
        return new Response(JSON.stringify({ success: true, ignored: true, message: "تم تجاهل التسجيل — وضع فحص/تسجيل كارت شغّال حالياً" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // ✅ لو الكارت ده معطّل رسمياً من الأدمن، نرفض تسجيل الحضور بيه فوراً
      // (البورد بيبعت لدالة submit-rfid-scan ودالة تسجيل الحضور دي كل مرة بشكل مستقل، فلازم نفس التحقق هنا كمان)
      const { data: knownCard } = await supabase
        .from("system_cards").select("id, is_active, teacher_id, center_id").eq("card_uid", uid).maybeSingle();

      // ✅ الكارت ممكن يكون مربوط مباشرة بالمدرس، أو مربوط بالسنتر اللي المدرس تابع له
      // (لو المدرس تابع لسنتر، الكروت المخصصة للسنتر كله متاحة لكل مدرسيه)
      let cardBelongsToTeacher = knownCard?.teacher_id === clientId;
      if (!cardBelongsToTeacher && knownCard?.center_id) {
        const { data: teacherRow } = await supabase.from("teachers").select("center_id").eq("client_id", clientId).maybeSingle();
        cardBelongsToTeacher = !!teacherRow?.center_id && teacherRow.center_id === knownCard.center_id;
      }

      if (knownCard && cardBelongsToTeacher && !knownCard.is_active) {
        return new Response(JSON.stringify({ success: false, message: "⛔ الكارت ده معطّل حالياً" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const { data: cardSettings } = await supabase.from("system_settings").select("require_registered_cards").eq("id", 1).maybeSingle();
      if (cardSettings?.require_registered_cards) {
        const isRegisteredAndActive = knownCard && cardBelongsToTeacher && knownCard.is_active;
        if (!isRegisteredAndActive) {
          return new Response(JSON.stringify({ success: false, message: "⛔ الكارت ده مش مسجّل رسمياً أو مش مفعّل في النظام" }),
            { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
      }

      // ✅ وضع الكارت: دلوقتي بيدعم أكتر من عملية في نفس الوقت (حضور + دفع اشتراك + سداد مذكرة مع بعض)
      // بدل ما يكون وضع واحد بس شغال — كل عملية مفعّلة بتتنفّذ لوحدها، وبعدين نكمّل لتسجيل الحضور العادي
      const { data: cardMode } = await supabase.from("card_action_mode").select("*").eq("teacher_id", clientId).maybeSingle();

      // ✅ القارئ متعطّل تماماً بمعرفة المدرس نفسه — مايسجّلش أي حاجة خالص، حتى الحضور العادي
      if (!cardMode || !cardMode.is_enabled) {
        return new Response(JSON.stringify({ success: false, message: "⏸ جهاز القارئ متوقف حالياً، فعّله من لوحة التحكم الأول" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // ✅ المدة بقت قابلة للتخصيص من المدرس، بدل ما تكون 5 دقايق ثابتة دايماً
      const durationMs = (cardMode.duration_minutes || 30) * 60 * 1000;
      const extraModesActive = (cardMode.payment_enabled || cardMode.book_payment_enabled) &&
        (Date.now() - new Date(cardMode.set_at || cardMode.updated_at).getTime()) < durationMs;

      if (extraModesActive) {
        const { data: modeStudent } = await supabase
          .from("students").select("uid, name, group_name, parent_phone").eq("uid", uid).eq("teacher_id", clientId).maybeSingle();

        if (!modeStudent) {
          return new Response(JSON.stringify({ success: false, message: "⚠️ الكارت ده مش مربوط بأي طالب عندك" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }

        // ✅ نمدّد المهلة مع كل كارت ناجح، عشان يقدر يكمّل يمرّغ كروت تانية من غير ما الوضع يرجع لحضور فجأة
        await supabase.from("card_action_mode").update({ updated_at: new Date().toISOString() }).eq("teacher_id", clientId);

        if (cardMode.payment_enabled) {
          const { data: existingPayment } = await supabase
            .from("payments").select("id").eq("student_uid", uid).eq("teacher_id", clientId).eq("title", cardMode.payment_title).maybeSingle();
          if (existingPayment) {
            extraActionMessages.push(`⚠️ ${modeStudent.name} مسدّد بند "${cardMode.payment_title}" بالفعل`);
          } else {
            const { data: titleRow } = await supabase
              .from("payment_titles").select("default_amount").eq("teacher_id", clientId).eq("title", cardMode.payment_title).maybeSingle();
            const realTotalAmount = titleRow?.default_amount ?? Number(cardMode.payment_amount);

            if (Number(cardMode.payment_amount) > realTotalAmount) {
              extraActionMessages.push(`⚠️ مبلغ بند "${cardMode.payment_title}" أكبر من سعره الأصلي — اتلغى`);
            } else {
              await supabase.from("payments").insert({
                student_uid: uid, student_name: modeStudent.name, group_name: modeStudent.group_name, teacher_id: clientId,
                title: cardMode.payment_title, total_amount: Number(realTotalAmount), amount: Number(cardMode.payment_amount),
              });
              const isPartial = Number(cardMode.payment_amount) < Number(realTotalAmount);
              extraActionMessages.push(`💰 اتسجّل دفع "${cardMode.payment_title}"${isPartial ? " (دفعة جزئية)" : ""}`);
            }
          }
        }

        if (cardMode.book_payment_enabled) {
          const { data: bookRow } = await supabase.from("books").select("name, price").eq("id", cardMode.book_id).maybeSingle();
          const { data: existingBookPayment } = await supabase
            .from("book_payments").select("id").eq("student_uid", uid).eq("teacher_id", clientId).eq("book_id", cardMode.book_id).maybeSingle();
          if (existingBookPayment) {
            extraActionMessages.push(`⚠️ ${modeStudent.name} مسدّد المذكرة دي بالفعل`);
          } else if (bookRow && Number(cardMode.book_amount) > bookRow.price) {
            extraActionMessages.push(`⚠️ مبلغ المذكرة أكبر من سعرها الأصلي — اتلغى`);
          } else {
            await supabase.from("book_payments").insert({
              book_id: cardMode.book_id, student_uid: uid, student_name: modeStudent.name, group_name: modeStudent.group_name,
              teacher_id: clientId, amount: Number(cardMode.book_amount),
            });
            const isPartialBook = bookRow && Number(cardMode.book_amount) < bookRow.price;
            extraActionMessages.push(`📖 اتسجّل سداد "${bookRow?.name || "المذكرة"}"${isPartialBook ? " (دفعة جزئية)" : ""}`);
          }
        }

        // ✅ لو الحضور مش مفعّل ضمن الأوضاع الحالية، نكتفي بالعمليات الإضافية دي بس ونوقف هنا
        if (cardMode.attendance_enabled === false) {
          return new Response(JSON.stringify({ success: true, cardAction: "combo", message: extraActionMessages.join(" — ") }),
            { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
        // ✅ غير كده، نكمّل تسجيل الحضور العادي تحت، ونرفق رسائل العمليات الإضافية في الرد النهائي
      }
    } else {
      const payload = await verifyToken(req);
      const tokenClientId = payload.clientId || payload.teacherId;
      if (tokenClientId !== clientId) {
        return new Response(
          JSON.stringify({ success: false, message: "⛔ غير مصرح لك بهذه العملية" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      await requireAssistantPermission(payload, "manage_attendance");
    }
    await requireTeacherPlanPermission(clientId, "can_manage_students");

    const { data: student, error: studentError } = await supabase
      .from("students")
      .select("name, group_name, parent_phone")
      .eq("uid", uid)
      .eq("teacher_id", clientId)
      .single();

    if (studentError) {
      return new Response(
        JSON.stringify({ success: false, message: "UNREGISTERED" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const today = new Date().toISOString().split("T")[0];

    const { data: existing, error: existError } = await supabase
      .from("attendance")
      .select("id")
      .eq("student_uid", uid)
      .eq("date", today)
      .maybeSingle();

    if (existError) throw new Error(`فشل التحقق من الحضور: ${existError.message}`);

    if (existing) {
      return new Response(
        JSON.stringify({ success: false, message: "DUPLICATE_IGNORE" }),
        { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const now = new Date();
    const timeStr = now.toLocaleTimeString("ar-EG", {
      timeZone: "Africa/Cairo",
      hour: "2-digit",
      minute: "2-digit",
    });

    const { data: attendance, error: attError } = await supabase
      .from("attendance")
    // ✅ نحاول نلاقي أقرب حصة للمجموعة دي في نفس الوقت ده — عشان نربط الحضور بيها ونذكر اسمها لولي الأمر
    let matchedSessionId: number | null = null;
    let matchedSessionLabel: string | null = null;
    try {
      const cairoNow = new Date(new Date().toLocaleString("en-US", { timeZone: "Africa/Cairo" }));
      const todayDow = cairoNow.getDay();
      const nowMinutesForMatch = cairoNow.getHours() * 60 + cairoNow.getMinutes();
      const { data: todaySessions } = await supabase
        .from("group_sessions").select("*").eq("teacher_id", clientId).eq("group_name", student.group_name).eq("day_of_week", todayDow);
      if (todaySessions && todaySessions.length > 0) {
        let closest = todaySessions[0];
        let closestDiff = Infinity;
        for (const s of todaySessions) {
          const [h, m] = s.session_time.split(":").map(Number);
          const diff = Math.abs(nowMinutesForMatch - (h * 60 + m));
          if (diff < closestDiff) { closestDiff = diff; closest = s; }
        }
        // ✅ نقبل المطابقة بس لو الحصة قريبة معقول من الوقت الحالي (خلال ساعتين)، مش أي حصة في اليوم
        if (closestDiff <= 120) {
          matchedSessionId = closest.id;
          matchedSessionLabel = closest.session_label || `حصة الساعة ${closest.session_time.slice(0, 5)}`;
        }
      }
    } catch (_e) { /* مطابقة الحصة اختيارية، مش لازم توقف تسجيل الحضور لو فشلت */ }

    const { data: attendance, error: attError } = await supabase.from("attendance")
      .insert({
        student_uid: uid,
        student_name: student.name,
        group_name: student.group_name,
        teacher_id: clientId,
        date: today,
        time: timeStr,
        status: "present",
        is_manual: manual === true,
        notes: notes || null,
        session_id: matchedSessionId,
      })
      .select()
      .single();

    if (attError) throw new Error(`فشل تسجيل الحضور: ${attError.message}`);

    if (student.parent_phone) {
      // ✅ نجيب اسم المدرس عشان يبقى واضح لولي الأمر مين اللي بعت الإشعار (مهم لو عنده أكتر من ابن عند مدرسين مختلفين)
      const { data: notifyTeacherInfo } = await supabase.from("teachers").select("name").eq("client_id", clientId).maybeSingle();
      const teacherLabel = notifyTeacherInfo?.name ? ` — مدرس ${notifyTeacherInfo.name}` : "";
      const sessionPart = matchedSessionLabel ? ` (${matchedSessionLabel})` : "";
      const attendanceMsg = `تم تسجيل حضور ${student.name}${sessionPart} اليوم الساعة ${timeStr}${teacherLabel}`;
      await supabase.from("notifications").insert({
        teacher_id: clientId,
        parent_phone: student.parent_phone,
        student_uid: uid,
        type: "attendance",
        title: "تسجيل حضور",
        message: attendanceMsg,
        details: { student_name: student.name, time: timeStr, date: today, session_label: matchedSessionLabel },
      }).then(({ error }) => { if (error) console.error("⚠️ فشل إرسال إشعار الحضور:", error.message); });
      sendPushToRecipient(supabase, "parent", student.parent_phone, "تسجيل حضور", attendanceMsg);
    }

    let performerName = "مدرس";
    if (assistantId) {
      const { data: assistantInfo } = await supabase.from("assistants").select("name").eq("id", assistantId).maybeSingle();
      performerName = assistantInfo?.name || "مساعد";
    } else {
      const { data: teacherInfo } = await supabase.from("teachers").select("name").eq("client_id", clientId).maybeSingle();
      performerName = teacherInfo?.name || "مدرس";
    }

    await supabase.from("activity_logs").insert({
      client_id: clientId,
      action_type: "record_attendance",
      details: {
        student_name: student.name,
        student_uid: uid,
        is_manual: manual === true,
        notes: notes || null,
      },
      performer_id: assistantId || clientId,
      performer_role: assistantId ? "assistant" : "teacher",
      performer_name: performerName,
    });

    const finalMessage = extraActionMessages.length > 0
      ? `✅ تم تسجيل الحضور بنجاح — ${extraActionMessages.join(" — ")}`
      : "تم تسجيل الحضور بنجاح";

    return new Response(
      JSON.stringify({ success: true, message: finalMessage, data: attendance, extraActions: extraActionMessages }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    if (error instanceof AuthError) return authErrorResponse(error);
    console.error("❌ خطأ:", error);
    return new Response(
      JSON.stringify({ success: false, message: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
// supabase/functions/check-session-absences/index.ts
// ✅ بتتنادى دورياً (كل ما حد فاتح لوحة التحكم، أو عبر جدولة) — بتفحص كل الحصص اللي وقتها فات
// بالمدة اللي المدرس حددها (absence_threshold_minutes)، ولسه محدش سجّل حضور فيها، وتسجّلهم غايبين + تبعت إشعار
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
};

interface TokenPayload { sub: string; clientId?: string; teacherId?: string; role: string; name: string; }

async function verifyToken(req: Request): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw new Error("⚠️ التوكن مطلوب");
  const token = authHeader.substring(7);
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) throw new Error("⚠️ JWT_SECRET غير مضبوط");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(JWT_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  return (await verify(token, key, "HS256")) as unknown as TokenPayload;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const payload = await verifyToken(req);
    const tokenClientId = payload.clientId || payload.teacherId;
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const { data: teacher } = await supabase.from("teachers").select("absence_threshold_minutes, name").eq("client_id", tokenClientId).maybeSingle();
    const thresholdMinutes = teacher?.absence_threshold_minutes ?? 30;

    // ✅ وقت النهاردة بتوقيت القاهرة (مش UTC)، عشان نطابق اليوم والوقت صح
    const now = new Date();
    const cairoNow = new Date(now.toLocaleString("en-US", { timeZone: "Africa/Cairo" }));
    const todayDayOfWeek = cairoNow.getDay(); // 0=الأحد
    const todayDateStr = cairoNow.toISOString().split("T")[0];
    const nowMinutes = cairoNow.getHours() * 60 + cairoNow.getMinutes();

    const { data: sessions } = await supabase
      .from("group_sessions").select("*").eq("teacher_id", tokenClientId).eq("day_of_week", todayDayOfWeek);

    if (!sessions || sessions.length === 0) {
      return new Response(JSON.stringify({ success: true, message: "مفيش حصص محددة النهاردة", absentCount: 0 }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    let totalAbsentMarked = 0;
    const notifRows: any[] = [];

    for (const session of sessions) {
      const [h, m] = session.session_time.split(":").map(Number);
      const sessionMinutes = h * 60 + m;

      // ✅ الحصة دي وقتها فات بالمدة المحددة؟ لو لأ، نتخطاها (لسه بدري نحكم على غياب حد)
      if (nowMinutes - sessionMinutes < thresholdMinutes) continue;

      const sessionStartUtc = new Date(`${todayDateStr}T${session.session_time}:00+02:00`); // مصر UTC+2 شتاءً/+3 صيفاً تقريباً، تقريب معقول
      const sessionEndWindow = new Date(sessionStartUtc.getTime() + thresholdMinutes * 60 * 1000);

      const { data: groupStudents } = await supabase
        .from("students").select("uid, name, parent_phone").eq("teacher_id", tokenClientId).eq("group_name", session.group_name);

      if (!groupStudents || groupStudents.length === 0) continue;

      const { data: presentToday } = await supabase
        .from("attendance").select("student_uid")
        .in("student_uid", groupStudents.map((s: any) => s.uid))
        .gte("created_at", sessionStartUtc.toISOString());

      const presentUids = new Set((presentToday || []).map((a: any) => a.student_uid));

      // ✅ هل سبق اتسجّل غياب لنفس الحصة دي النهاردة؟ (منع تكرار الإشعار لو الدالة اتنادت أكتر من مرة)
      const { data: alreadyMarked } = await supabase
        .from("attendance").select("student_uid").eq("session_id", session.id).eq("is_absent", true)
        .gte("created_at", sessionStartUtc.toISOString());
      const alreadyMarkedUids = new Set((alreadyMarked || []).map((a: any) => a.student_uid));

      for (const student of groupStudents) {
        if (presentUids.has(student.uid) || alreadyMarkedUids.has(student.uid)) continue;

        await supabase.from("attendance").insert({
          student_uid: student.uid, teacher_id: tokenClientId, group_name: session.group_name,
          session_id: session.id, is_absent: true, created_at: new Date().toISOString(),
        });
        totalAbsentMarked++;

        if (student.parent_phone) {
          notifRows.push({
            teacher_id: tokenClientId, parent_phone: student.parent_phone, student_uid: student.uid,
            type: "absence", title: "تسجيل غياب",
            message: `${student.name} محضرش حصة ${session.session_label || session.group_name} النهاردة الساعة ${session.session_time}`,
            details: { student_name: student.name, group_name: session.group_name, session_time: session.session_time },
          });
        }
      }
    }

    if (notifRows.length > 0) {
      await supabase.from("notifications").insert(notifRows);
    }

    return new Response(JSON.stringify({ success: true, message: `✅ اتسجّل غياب ${totalAbsentMarked} طالب`, absentCount: totalAbsentMarked }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "حدث خطأ داخلي";
    return new Response(JSON.stringify({ success: false, message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

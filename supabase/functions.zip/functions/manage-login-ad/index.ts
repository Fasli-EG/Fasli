// supabase/functions/manage-login-ad/index.ts
// ✅ دالة موحّدة تجمع add-login-ad + delete-login-ad — action: add | delete
// كل واحدة منهم أصلاً بتدعم 3 أنواع (type: ad | album | album_image)، محافظين على المنطق ده بالكامل
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
};

interface TokenPayload { sub: string; clientId?: string; role: string; name: string; }

class AuthError extends Error {
  status: number; code?: string;
  constructor(message: string, status = 401, code?: string) { super(message); this.status = status; this.code = code; }
}

async function verifyToken(req: Request): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw new AuthError("⚠️ التوكن مطلوب", 401);
  const token = authHeader.substring(7);
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) throw new Error("⚠️ JWT_SECRET غير مضبوط");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(JWT_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  try { return (await verify(token, key, "HS256")) as unknown as TokenPayload; }
  catch (_e) { throw new AuthError("⚠️ التوكن غير صالح أو منتهي الصلاحية", 401); }
}

function requireAdmin(payload: TokenPayload) {
  if (payload.role !== "teacher" || payload.clientId !== "master_admin") {
    throw new AuthError("⛔ غير مصرح بهذه العملية", 403);
  }
}

function authErrorResponse(error: unknown) {
  const status = error instanceof AuthError ? error.status : 500;
  const code = error instanceof AuthError ? error.code : undefined;
  const message = error instanceof Error ? error.message : "⚠️ خطأ غير معروف";
  return new Response(JSON.stringify({ success: false, message, ...(code ? { code } : {}) }),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

// ============================================
// ⭐ العملية 1: إضافة (إعلان عادي، أو ألبوم جديد، أو صورة لألبوم)
// ============================================
async function handleAdd(supabase: any, body: any) {
  const type = body.type || "ad";

  if (type === "album") {
    const { title, description, isBackground } = body;
    if (!title) {
      return new Response(JSON.stringify({ success: false, message: "⚠️ اسم الألبوم مطلوب" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const { count } = await supabase.from("photo_albums").select("id", { count: "exact", head: true });
    const { data: album, error } = await supabase.from("photo_albums")
      .insert({ title, description: description || null, sort_order: count || 0, is_background: isBackground === true }).select().single();
    if (error) {
      console.error("❌ فشل إنشاء الألبوم:", error);
      return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    return new Response(JSON.stringify({ success: true, message: "✅ تم إنشاء الألبوم بنجاح", data: album }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  if (type === "album_image") {
    const { albumId, imageUrl } = body;
    if (!albumId || !imageUrl) {
      return new Response(JSON.stringify({ success: false, message: "⚠️ الألبوم ورابط الصورة مطلوبين" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const { count } = await supabase.from("photo_album_images").select("id", { count: "exact", head: true }).eq("album_id", albumId);
    const { data: image, error } = await supabase.from("photo_album_images")
      .insert({ album_id: albumId, image_url: imageUrl, sort_order: count || 0 }).select().single();
    if (error) {
      console.error("❌ فشل إضافة صورة الألبوم:", error);
      return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    return new Response(JSON.stringify({ success: true, message: "✅ تم إضافة الصورة للألبوم", data: image }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  // ✅ إضافة صورة إعلانية عادية (السلوك الأصلي)
  const { imageUrl, linkUrl } = body;
  if (!imageUrl) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ رابط الصورة مطلوب" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  const { count } = await supabase.from("login_ads").select("id", { count: "exact", head: true });
  const { data: ad, error } = await supabase.from("login_ads")
    .insert({ image_url: imageUrl, link_url: linkUrl || null, sort_order: count || 0 }).select().single();
  if (error) {
    console.error("❌ فشل إضافة الصورة الإعلانية:", error);
    return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  return new Response(JSON.stringify({ success: true, message: "✅ تم إضافة الصورة بنجاح", data: ad }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

// ============================================
// ⭐ العملية 2: حذف (إعلان عادي، أو ألبوم، أو صورة من ألبوم)
// ============================================
async function handleDelete(supabase: any, body: any) {
  const type = body.type || "ad";

  if (type === "album") {
    const { albumId } = body;
    if (!albumId) {
      return new Response(JSON.stringify({ success: false, message: "⚠️ albumId مطلوب" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const { error } = await supabase.from("photo_albums").delete().eq("id", albumId);
    if (error) {
      console.error("❌ فشل حذف الألبوم:", error);
      return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    return new Response(JSON.stringify({ success: true, message: "✅ تم حذف الألبوم بنجاح" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  if (type === "album_image") {
    const { imageId } = body;
    if (!imageId) {
      return new Response(JSON.stringify({ success: false, message: "⚠️ imageId مطلوب" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const { error } = await supabase.from("photo_album_images").delete().eq("id", imageId);
    if (error) {
      console.error("❌ فشل حذف الصورة:", error);
      return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    return new Response(JSON.stringify({ success: true, message: "✅ تم حذف الصورة بنجاح" }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  // ✅ حذف صورة إعلانية عادية (السلوك الأصلي)
  const { adId } = body;
  if (!adId) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ adId مطلوب" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  const { error } = await supabase.from("login_ads").delete().eq("id", adId);
  if (error) {
    console.error("❌ فشل حذف الصورة الإعلانية:", error);
    return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  return new Response(JSON.stringify({ success: true, message: "✅ تم حذف الصورة بنجاح" }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });
  try {
    const payload = await verifyToken(req);
    requireAdmin(payload);
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
      { auth: { autoRefreshToken: false, persistSession: false } });

    const body = await req.json();
    const action = body.action;

    if (action === "add") return await handleAdd(supabase, body);
    if (action === "delete") return await handleDelete(supabase, body);

    return new Response(JSON.stringify({ success: false, message: "⚠️ action غير معروفة" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    if (error instanceof AuthError) return authErrorResponse(error);
    console.error("❌ خطأ غير متوقع:", error);
    return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

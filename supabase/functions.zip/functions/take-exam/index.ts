// supabase/functions/take-exam/index.ts
// ✅ دالة موحّدة لأداء الاختبار (جانب الطالب) — action: start | submit
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
};

interface TokenPayload { sub: string; role: string; name: string; }

async function verifyToken(req: Request): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw new Error("⚠️ التوكن مطلوب");
  const token = authHeader.substring(7);
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) throw new Error("⚠️ JWT_SECRET غير مضبوط");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(JWT_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  return (await verify(token, key, "HS256")) as unknown as TokenPayload;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const payload = await verifyToken(req);
    if (payload.role !== "student") {
      return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const studentUid = payload.sub;
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");

    const body = await req.json();
    const action = body.action;

    // ✅ التأكد إن الطالب ده أصلاً من ضمن مجموعة الاختبار، قبل أي حاجة تانية
    async function verifyEligibility(examId: number) {
      const { data: exam } = await supabase.from("online_exams").select("*").eq("id", examId).maybeSingle();
      if (!exam || !exam.is_published) throw new Error("⚠️ الاختبار غير متاح");
      const { data: student } = await supabase.from("students").select("group_name, name").eq("uid", studentUid).maybeSingle();
      if (!student || student.group_name !== exam.group_name) throw new Error("⛔ الاختبار ده مش لمجموعتك");

      // ✅ لو المدرس حدد طلاب معيّنين للاختبار ده، لازم الطالب يكون من ضمنهم
      const { data: targets } = await supabase.from("exam_target_students").select("student_uid").eq("exam_id", examId);
      if (targets && targets.length > 0) {
        const isTargeted = targets.some((t: any) => t.student_uid === studentUid);
        if (!isTargeted) throw new Error("⛔ الاختبار ده مش موجّه ليك");
      }

      return { exam, studentName: student.name };
    }

    if (action === "start") {
      const { examId } = body;
      const mode = body.mode === "practice" ? "practice" : "official";
      const { exam } = await verifyEligibility(examId);

      // ✅ وضع التدريب: مفيش قفل على عدد المحاولات ولا وقت — كل ضغطة "ابدأ" بتفتح محاولة تدريب جديدة
      // منفصلة تماماً عن المحاولة الرسمية (ماتظهرش في تقارير المدرس ولا بتمنع محاولة رسمية)
      if (mode === "practice") {
        const { data: attempt, error } = await supabase.from("exam_attempts").insert({
          exam_id: examId, student_uid: studentUid, status: "in_progress", mode: "practice",
        }).select().single();
        if (error) throw new Error(error.message);
        const { data: questions } = await supabase.from("exam_questions").select("id, question_text, question_type, options, points").eq("exam_id", examId).order("order_index");
        return new Response(JSON.stringify({
          success: true, attemptId: attempt.id, startedAt: attempt.started_at, mode: "practice",
          durationMinutes: null, title: exam.title, questions: questions || [],
        }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      // ✅ لو عنده محاولة رسمية سابقة (مكتملة أو منتهي وقتها)، مايقدرش يبدأ تاني
      const { data: existing } = await supabase.from("exam_attempts").select("*").eq("exam_id", examId).eq("student_uid", studentUid).eq("mode", "official").maybeSingle();
      if (existing) {
        if (existing.status !== "in_progress") {
          return new Response(JSON.stringify({ success: false, message: "⚠️ خلّصت الاختبار ده قبل كده" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
        // ✅ محاولة شغّالة بالفعل — نتأكد لو وقتها لسه ماخلصش، ونرجّعها بدل ما نعمل واحدة جديدة
        const elapsedMs = Date.now() - new Date(existing.started_at).getTime();
        if (elapsedMs > exam.duration_minutes * 60 * 1000) {
          return new Response(JSON.stringify({ success: false, message: "⚠️ انتهى وقت الاختبار ده بالفعل، هيتقفل تلقائياً" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
        }
        const { data: questions } = await supabase.from("exam_questions").select("id, question_text, question_type, options, points").eq("exam_id", examId).order("order_index");
        return new Response(JSON.stringify({
          success: true, attemptId: existing.id, startedAt: existing.started_at, mode: "official",
          durationMinutes: exam.duration_minutes, title: exam.title, questions: questions || [],
        }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const { data: attempt, error } = await supabase.from("exam_attempts").insert({
        exam_id: examId, student_uid: studentUid, status: "in_progress", mode: "official",
      }).select().single();
      if (error) throw new Error(error.message);

      // ✅ الأسئلة بترجع من غير الإجابة الصحيحة خالص، عشان الطالب مايشوفهاش في كود الصفحة
      const { data: questions } = await supabase.from("exam_questions").select("id, question_text, question_type, options, points").eq("exam_id", examId).order("order_index");

      return new Response(JSON.stringify({
        success: true, attemptId: attempt.id, startedAt: attempt.started_at, mode: "official",
        durationMinutes: exam.duration_minutes, title: exam.title, questions: questions || [],
      }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    if (action === "submit") {
      const { attemptId, answers } = body; // answers: [{ questionId, selectedAnswer }]
      const { data: attempt } = await supabase.from("exam_attempts").select("*").eq("id", attemptId).maybeSingle();
      if (!attempt || attempt.student_uid !== studentUid) {
        return new Response(JSON.stringify({ success: false, message: "⛔ غير مصرح لك" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }
      if (attempt.status !== "in_progress") {
        return new Response(JSON.stringify({ success: false, message: "⚠️ الاختبار ده اتقفل بالفعل" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      }

      const { data: exam } = await supabase.from("online_exams").select("duration_minutes").eq("id", attempt.exam_id).maybeSingle();
      const elapsedMs = Date.now() - new Date(attempt.started_at).getTime();
      // ✅ وضع التدريب بلا وقت أبداً — التوقيت بيتفعّل بس للمحاولة الرسمية
      const isTimedOut = attempt.mode !== "practice" && exam && elapsedMs > exam.duration_minutes * 60 * 1000;

      const { data: questions } = await supabase.from("exam_questions").select("*").eq("exam_id", attempt.exam_id);
      const questionsById: Record<number, any> = {};
      (questions || []).forEach((q: any) => { questionsById[q.id] = q; });

      let totalScore = 0;
      let totalPossible = 0;
      const answerRows = [];

      for (const q of questions || []) {
        totalPossible += Number(q.points);
        const submitted = (answers || []).find((a: any) => a.questionId === q.id);
        const selectedAnswer = submitted?.selectedAnswer ?? null;
        // ✅ لو الوقت خلص، أي سؤال متأخر ماكانش الطالب سلّمه بيتحسب غلط تلقائياً (مش بيتجاهل)
        const isCorrect = !isTimedOut && selectedAnswer !== null && String(selectedAnswer).trim() === String(q.correct_answer).trim();
        const pointsEarned = isCorrect ? Number(q.points) : 0;
        totalScore += pointsEarned;
        answerRows.push({ attempt_id: attemptId, question_id: q.id, selected_answer: selectedAnswer, is_correct: isCorrect, points_earned: pointsEarned });
      }

      if (answerRows.length > 0) await supabase.from("exam_answers").insert(answerRows);

      await supabase.from("exam_attempts").update({
        status: isTimedOut ? "timed_out" : "completed",
        finished_at: new Date().toISOString(),
        score: totalScore, total_possible: totalPossible,
      }).eq("id", attemptId);

      return new Response(JSON.stringify({
        success: true,
        message: attempt.mode === "practice"
          ? "✅ خلّصت محاولة التدريب — مش هتتحسب في تقرير المدرس"
          : (isTimedOut ? "⏰ انتهى وقت الاختبار، اتصحّح تلقائياً" : "✅ تم تسليم الاختبار وتصحيحه"),
        score: totalScore, totalPossible, isTimedOut, mode: attempt.mode,
      }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    return new Response(JSON.stringify({ success: false, message: "⚠️ action غير معروفة" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "حدث خطأ داخلي";
    return new Response(JSON.stringify({ success: false, message }),
      { status: message.includes("⛔") ? 403 : 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});

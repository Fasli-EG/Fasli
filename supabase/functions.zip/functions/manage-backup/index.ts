// supabase/functions/manage-backup/index.ts
// ✅ دالة موحّدة تجمع export-backup + restore-backup — action: export | restore
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { verify } from "https://deno.land/x/djwt@v2.8/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, apikey, x-client-info",
};

interface TokenPayload { sub: string; clientId?: string; teacherId?: string; role: string; name: string; }

class AuthError extends Error {
  status: number; code?: string;
  constructor(message: string, status = 401, code?: string) { super(message); this.status = status; this.code = code; }
}

async function verifyToken(req: Request): Promise<TokenPayload> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) throw new AuthError("⚠️ التوكن مطلوب", 401);
  const token = authHeader.substring(7);
  const JWT_SECRET = Deno.env.get("JWT_SECRET");
  if (!JWT_SECRET) throw new Error("⚠️ JWT_SECRET غير مضبوط");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(JWT_SECRET), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  try { return (await verify(token, key, "HS256")) as unknown as TokenPayload; }
  catch (_e) { throw new AuthError("⚠️ التوكن غير صالح أو منتهي الصلاحية", 401); }
}

function requireOwnClientId(payload: TokenPayload, requestedClientId?: string | null): string {
  const tokenClientId = payload.clientId || payload.teacherId;
  if (!tokenClientId) throw new AuthError("⚠️ التوكن لا يحتوي على clientId", 401);
  if (requestedClientId && requestedClientId !== tokenClientId) throw new AuthError("⛔ غير مصرح لك بمشاهدة بيانات هذا المدرس", 403);
  return tokenClientId;
}

async function requireTeacherPlanPermission(supabase: any, clientId: string, permKey: string): Promise<void> {
  if (clientId === "master_admin") return;
  const { data: teacher } = await supabase.from("teachers").select("permissions").eq("client_id", clientId).maybeSingle();
  const perms = teacher?.permissions || {};
  if (perms[permKey] === false) throw new AuthError("⛔ هذه الميزة غير متاحة في باقتك الحالية، تواصل مع الإدارة لتفعيلها", 403, "PLAN_RESTRICTED");
}

function authErrorResponse(error: unknown) {
  const status = error instanceof AuthError ? error.status : 500;
  const code = error instanceof AuthError ? error.code : undefined;
  const message = error instanceof Error ? error.message : "⚠️ خطأ غير معروف";
  return new Response(JSON.stringify({ success: false, message, ...(code ? { code } : {}) }),
    { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

// ============================================
// هاش وتحقق كلمات المرور (لازمة لـ restore بس، لكن مفيش ضرر من وجودها في export كمان)
// ============================================
const ITERATIONS = 100_000;
function toHex(bytes: Uint8Array): string { return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join(""); }
function fromHex(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.substring(i * 2, i * 2 + 2), 16);
  return bytes;
}
async function pbkdf2(password: string, salt: Uint8Array, iterations: number): Promise<Uint8Array> {
  const keyMaterial = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, keyMaterial, 256);
  return new Uint8Array(bits);
}
function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
async function legacySha256(text: string): Promise<string> {
  const data = new TextEncoder().encode(text);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  return toHex(new Uint8Array(hashBuffer));
}
async function verifyPassword(password: string, storedHash: string): Promise<{ valid: boolean }> {
  if (storedHash.startsWith("pbkdf2$")) {
    const parts = storedHash.split("$");
    if (parts.length !== 4) return { valid: false };
    const [, iterStr, saltHex, hashHex] = parts;
    const salt = fromHex(saltHex);
    const computed = await pbkdf2(password, salt, parseInt(iterStr, 10));
    return { valid: timingSafeEqual(toHex(computed), hashHex) };
  }
  const legacy = await legacySha256(password);
  return { valid: timingSafeEqual(legacy, storedHash) };
}

// ============================================
// حماية من التخمين المتكرر (نفس منطق _shared/rateLimit.ts الأصلي)
// ============================================
async function checkRateLimit(supabase: any, key: string): Promise<{ blocked: boolean; message?: string }> {
  const { data } = await supabase.from("login_attempts").select("attempts, locked_until").eq("username", key).maybeSingle();
  if (data?.locked_until && new Date(data.locked_until) > new Date()) {
    const minutes = Math.ceil((new Date(data.locked_until).getTime() - Date.now()) / 60000);
    return { blocked: true, message: `⛔ تم حظر المحاولات مؤقتاً، حاول بعد ${minutes} دقيقة` };
  }
  return { blocked: false };
}
async function registerFailedAttempt(supabase: any, key: string) {
  const { data } = await supabase.from("login_attempts").select("attempts").eq("username", key).maybeSingle();
  const attempts = (data?.attempts || 0) + 1;
  const lockedUntil = attempts >= 5 ? new Date(Date.now() + 15 * 60 * 1000).toISOString() : null;
  await supabase.from("login_attempts").upsert({ username: key, attempts, locked_until: lockedUntil, last_attempt: new Date().toISOString() });
}
async function clearAttempts(supabase: any, key: string) {
  await supabase.from("login_attempts").delete().eq("username", key);
}

// ============================================
// ⭐ العملية 1: تصدير نسخة احتياطية
// ============================================
async function handleExport(supabase: any, payload: TokenPayload, body: any) {
  const { clientId } = body;
  if (!clientId) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ clientId مطلوب" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  const finalClientId = requireOwnClientId(payload, clientId);
  if (payload.role === "assistant") {
    return new Response(JSON.stringify({ success: false, message: "⛔ النسخ الاحتياطي متاح للمدرس بس" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  await requireTeacherPlanPermission(supabase, finalClientId, "can_use_backup");

  const [teacherRes, studentsRes, groupsRes, gradesRes, paymentsRes, booksRes, bookPaymentsRes, attendanceRes, assistantsRes] = await Promise.all([
    supabase.from("teachers").select("client_id, name, expiry_date, max_students, permissions, contact_whatsapp, contact_phone").eq("client_id", finalClientId).maybeSingle(),
    supabase.from("students").select("*").eq("teacher_id", finalClientId),
    supabase.from("groups").select("*").eq("teacher_id", finalClientId),
    supabase.from("grades").select("*").eq("teacher_id", finalClientId),
    supabase.from("payments").select("*").eq("teacher_id", finalClientId),
    supabase.from("books").select("*").eq("teacher_id", finalClientId),
    supabase.from("book_payments").select("*").eq("teacher_id", finalClientId),
    supabase.from("attendance").select("*").eq("teacher_id", finalClientId),
    supabase.from("assistants").select("id, username, name, permissions, is_active").eq("teacher_id", finalClientId),
  ]);

  const backup = {
    exported_at: new Date().toISOString(),
    teacher: teacherRes.data,
    students: studentsRes.data || [],
    groups: groupsRes.data || [],
    grades: gradesRes.data || [],
    payments: paymentsRes.data || [],
    books: booksRes.data || [],
    book_payments: bookPaymentsRes.data || [],
    attendance: attendanceRes.data || [],
    assistants: assistantsRes.data || [],
  };

  await supabase.from("activity_logs").insert({
    client_id: finalClientId, teacher_id: finalClientId, action_type: "export_backup",
    details: { students_count: backup.students.length, grades_count: backup.grades.length, payments_count: backup.payments.length },
    performer_id: payload.sub, performer_role: payload.role, performer_name: payload.name,
  });

  return new Response(JSON.stringify({ success: true, data: backup }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

// ============================================
// ⭐ العملية 2: استعادة نسخة احتياطية
// ============================================
async function handleRestore(supabase: any, payload: TokenPayload, body: any) {
  const { clientId, password, backup } = body;
  if (!clientId || !password || !backup) {
    return new Response(JSON.stringify({ success: false, message: "⚠️ clientId وكلمة المرور وملف النسخة الاحتياطية مطلوبين" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  const finalClientId = requireOwnClientId(payload, clientId);
  if (payload.role === "assistant") {
    return new Response(JSON.stringify({ success: false, message: "⛔ النسخ الاحتياطي متاح للمدرس بس" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  await requireTeacherPlanPermission(supabase, finalClientId, "can_use_backup");

  const rateLimitKey = `restore-backup:${finalClientId}`;
  const rateLimit = await checkRateLimit(supabase, rateLimitKey);
  if (rateLimit.blocked) {
    return new Response(JSON.stringify({ success: false, message: rateLimit.message }),
      { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const { data: teacherRow, error: teacherError } = await supabase.from("teachers").select("password_hash").eq("client_id", finalClientId).maybeSingle();
  if (teacherError || !teacherRow) {
    return new Response(JSON.stringify({ success: false, message: "تعذر التحقق من الحساب" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  const { valid } = await verifyPassword(password, teacherRow.password_hash);
  if (!valid) {
    await registerFailedAttempt(supabase, rateLimitKey);
    return new Response(JSON.stringify({ success: false, message: "⛔ كلمة المرور غير صحيحة" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
  await clearAttempts(supabase, rateLimitKey);

  if (backup.teacher && backup.teacher.client_id && backup.teacher.client_id !== finalClientId) {
    return new Response(JSON.stringify({ success: false, message: "⛔ هذه النسخة الاحتياطية ليست تابعة لحسابك" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  // 1) مسح البيانات الحالية بالكامل
  const { data: currentStudents } = await supabase.from("students").select("uid").eq("teacher_id", finalClientId);
  const currentUids = (currentStudents || []).map((s: any) => s.uid);

  await supabase.from("attendance").delete().eq("teacher_id", finalClientId);
  await supabase.from("book_payments").delete().eq("teacher_id", finalClientId);
  await supabase.from("books").delete().eq("teacher_id", finalClientId);
  if (currentUids.length > 0) {
    await supabase.from("payments").delete().in("student_uid", currentUids);
    await supabase.from("grades").delete().in("student_uid", currentUids);
  }
  await supabase.from("students").delete().eq("teacher_id", finalClientId);
  try {
    const { error: checkError } = await supabase.from("groups").select("id").limit(1);
    if (!checkError) await supabase.from("groups").delete().eq("teacher_id", finalClientId);
  } catch (_) { /* جدول groups قد لا يكون موجوداً */ }

  // 2) إعادة إدراج بيانات النسخة الاحتياطية
  const clean = (rows: any[]) => (rows || []).map((r: any) => { const { id, ...rest } = r; return rest; });
  let restoredCounts: Record<string, number> = {};

  if (backup.groups?.length) {
    const { error } = await supabase.from("groups").insert(clean(backup.groups));
    if (error) console.error("⚠️ فشل استعادة المجموعات:", error.message);
    restoredCounts.groups = backup.groups.length;
  }
  if (backup.students?.length) {
    let restored = 0;
    for (const student of backup.students) {
      const { error } = await supabase.from("students").insert(student);
      if (error) console.error(`⚠️ فشل استعادة الطالب ${student.name || student.uid}:`, error.message);
      else restored++;
    }
    restoredCounts.students = restored;
  }
  if (backup.grades?.length) {
    const { error } = await supabase.from("grades").insert(clean(backup.grades));
    if (error) console.error("⚠️ فشل استعادة الدرجات:", error.message);
    restoredCounts.grades = backup.grades.length;
  }
  if (backup.payments?.length) {
    const { error } = await supabase.from("payments").insert(clean(backup.payments));
    if (error) console.error("⚠️ فشل استعادة المدفوعات:", error.message);
    restoredCounts.payments = backup.payments.length;
  }
  if (backup.books?.length) {
    const { error } = await supabase.from("books").insert(backup.books);
    if (error) console.error("⚠️ فشل استعادة المذكرات:", error.message);
    restoredCounts.books = backup.books.length;
  }
  if (backup.book_payments?.length) {
    const { error } = await supabase.from("book_payments").insert(clean(backup.book_payments));
    if (error) console.error("⚠️ فشل استعادة سدادات المذكرات:", error.message);
    restoredCounts.book_payments = backup.book_payments.length;
  }
  if (backup.attendance?.length) {
    const { error } = await supabase.from("attendance").insert(clean(backup.attendance));
    if (error) console.error("⚠️ فشل استعادة الحضور:", error.message);
    restoredCounts.attendance = backup.attendance.length;
  }

  await supabase.from("teachers").update({ student_count: backup.students?.length || 0 }).eq("client_id", finalClientId);

  await supabase.from("activity_logs").insert({
    client_id: finalClientId, teacher_id: finalClientId, action_type: "restore_backup",
    details: { ...restoredCounts, restored_at: new Date().toISOString() },
    performer_id: payload.sub, performer_role: payload.role, performer_name: payload.name,
  });

  return new Response(JSON.stringify({ success: true, message: "✅ تم استعادة النسخة الاحتياطية بنجاح", data: restoredCounts }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders, status: 200 });
  try {
    const payload = await verifyToken(req);
    const supabase = createClient(Deno.env.get("SUPABASE_URL") ?? "", Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "");

    const body = await req.json();
    const action = body.action;

    if (action === "export") return await handleExport(supabase, payload, body);
    if (action === "restore") return await handleRestore(supabase, payload, body);

    return new Response(JSON.stringify({ success: false, message: "⚠️ action غير معروفة" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (error) {
    if (error instanceof AuthError) return authErrorResponse(error);
    console.error("❌ خطأ في manage-backup:", error);
    return new Response(JSON.stringify({ success: false, message: "⚠️ حدث خطأ غير متوقع، حاول مرة أخرى" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
